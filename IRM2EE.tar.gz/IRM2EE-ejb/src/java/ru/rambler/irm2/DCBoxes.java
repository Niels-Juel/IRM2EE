/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.rambler.irm2;

import java.util.List;
import java.util.Map;
import javax.xml.bind.annotation.*;

/**
 *
 * @author a.shalin
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class DCBoxes {
    @XmlElement(name = "name")
    private String name;
    
    @XmlElement(name="boxes")
    private List<Integer> boxes;
    
    @XmlElement(name="badBoxes")
    private List<Integer> badBoxes;
    
    @XmlElement(name="disks")
    private Map<String, Integer> disks;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Integer> getBoxes() {
        return boxes;
    }

    public void setBoxes(List<Integer> boxes) {
        this.boxes = boxes;
    }

    public List<Integer> getBadBoxes() {
        return badBoxes;
    }

    public void setBadBoxes(List<Integer> badBoxes) {
        this.badBoxes = badBoxes;
    }

    public Map<String, Integer> getDisks() {
        return disks;
    }

    public void setDisks(Map<String, Integer> disks) {
        this.disks = disks;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.rambler.irm2.entries;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author a.shalin
 */
@Entity
@Table(name = "event_log")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "EventLog.findAll", query = "SELECT e FROM EventLog e"),
    @NamedQuery(name = "EventLog.findById", query = "SELECT e FROM EventLog e WHERE e.id = :id"),
    @NamedQuery(name = "EventLog.findByItem", query = "SELECT e FROM EventLog e WHERE e.item = :item"),
    @NamedQuery(name = "EventLog.findByItemtype", query = "SELECT e FROM EventLog e WHERE e.itemtype = :itemtype"),
    @NamedQuery(name = "EventLog.findByDate", query = "SELECT e FROM EventLog e WHERE e.date = :date"),
    @NamedQuery(name = "EventLog.findByService", query = "SELECT e FROM EventLog e WHERE e.service = :service"),
    @NamedQuery(name = "EventLog.findByLevel", query = "SELECT e FROM EventLog e WHERE e.level = :level"),
    @NamedQuery(name = "EventLog.findByAction", query = "SELECT e FROM EventLog e WHERE e.action = :action"),
    @NamedQuery(name = "EventLog.findByUser", query = "SELECT e FROM EventLog e WHERE e.user = :user")})
public class EventLog implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @Column(name = "item")
    private Integer item;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "itemtype")
    private String itemtype;
    @Basic(optional = false)
    @NotNull
    @Column(name = "date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date date;
    @Size(max = 20)
    @Column(name = "service")
    private String service;
    @Basic(optional = false)
    @NotNull
    @Column(name = "level")
    private short level;
    @Basic(optional = false)
    @NotNull
    @Lob
    @Size(min = 1, max = 65535)
    @Column(name = "message")
    private String message;
    @Size(max = 20)
    @Column(name = "action")
    private String action;
    @Size(max = 30)
    @Column(name = "user")
    private String user;

    public EventLog() {
    }

    public EventLog(Integer id) {
        this.id = id;
    }

    public EventLog(Integer id, String itemtype, Date date, short level, String message) {
        this.id = id;
        this.itemtype = itemtype;
        this.date = date;
        this.level = level;
        this.message = message;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getItem() {
        return item;
    }

    public void setItem(Integer item) {
        this.item = item;
    }

    public String getItemtype() {
        return itemtype;
    }

    public void setItemtype(String itemtype) {
        this.itemtype = itemtype;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public short getLevel() {
        return level;
    }

    public void setLevel(short level) {
        this.level = level;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof EventLog)) {
            return false;
        }
        EventLog other = (EventLog) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "irm2.entries.EventLog[ id=" + id + " ]";
    }
    
}

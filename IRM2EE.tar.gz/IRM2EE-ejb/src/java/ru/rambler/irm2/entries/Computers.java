/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ru.rambler.irm2.entries;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author a.shalin
 */
@Entity
@Table(name = "computers")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Computers.findAll", query = "SELECT c FROM Computers c"),
    @NamedQuery(name = "Computers.findById", query = "SELECT c FROM Computers c WHERE c.id = :id"),
    @NamedQuery(name = "Computers.findByName", query = "SELECT c FROM Computers c WHERE c.name = :name"),
    @NamedQuery(name = "Computers.findByAccName", query = "SELECT c FROM Computers c WHERE c.accName = :accName"),
    @NamedQuery(name = "Computers.findBySerial", query = "SELECT c FROM Computers c WHERE c.serial = :serial"),
    @NamedQuery(name = "Computers.findByInvNumber", query = "SELECT c FROM Computers c WHERE c.invNumber = :invNumber"),
    @NamedQuery(name = "Computers.findByOldInvNumber", query = "SELECT c FROM Computers c WHERE c.oldInvNumber = :oldInvNumber"),
    @NamedQuery(name = "Computers.findByHostingNumber", query = "SELECT c FROM Computers c WHERE c.hostingNumber = :hostingNumber"),
    @NamedQuery(name = "Computers.findByLeaseExpired", query = "SELECT c FROM Computers c WHERE c.leaseExpired = :leaseExpired"),
    @NamedQuery(name = "Computers.findByContact", query = "SELECT c FROM Computers c WHERE c.contact = :contact"),
    @NamedQuery(name = "Computers.findByRackUnit", query = "SELECT c FROM Computers c WHERE c.rackUnit = :rackUnit"),
    @NamedQuery(name = "Computers.findByBoxUnit", query = "SELECT c FROM Computers c WHERE c.boxUnit = :boxUnit"),
    @NamedQuery(name = "Computers.findByCost", query = "SELECT c FROM Computers c WHERE c.cost = :cost"),
    @NamedQuery(name = "Computers.findByBuyDate", query = "SELECT c FROM Computers c WHERE c.buyDate = :buyDate"),
    @NamedQuery(name = "Computers.findByMbManufact", query = "SELECT c FROM Computers c WHERE c.mbManufact = :mbManufact"),
    @NamedQuery(name = "Computers.findByMbType", query = "SELECT c FROM Computers c WHERE c.mbType = :mbType"),
    @NamedQuery(name = "Computers.findByMbSn", query = "SELECT c FROM Computers c WHERE c.mbSn = :mbSn"),
    @NamedQuery(name = "Computers.findByCpu", query = "SELECT c FROM Computers c WHERE c.cpu = :cpu"),
    @NamedQuery(name = "Computers.findByCpuSpeed", query = "SELECT c FROM Computers c WHERE c.cpuSpeed = :cpuSpeed"),
    @NamedQuery(name = "Computers.findByCpuPn", query = "SELECT c FROM Computers c WHERE c.cpuPn = :cpuPn"),
    @NamedQuery(name = "Computers.findByPsuPn", query = "SELECT c FROM Computers c WHERE c.psuPn = :psuPn"),
    @NamedQuery(name = "Computers.findByRam", query = "SELECT c FROM Computers c WHERE c.ram = :ram"),
    @NamedQuery(name = "Computers.findByGuarantee", query = "SELECT c FROM Computers c WHERE c.guarantee = :guarantee"),
    @NamedQuery(name = "Computers.findByPortConnected1", query = "SELECT c FROM Computers c WHERE c.portConnected1 = :portConnected1"),
    @NamedQuery(name = "Computers.findBySwitchConnectedId", query = "SELECT c FROM Computers c WHERE c.switchConnectedId = :switchConnectedId"),
    @NamedQuery(name = "Computers.findByContactNum", query = "SELECT c FROM Computers c WHERE c.contactNum = :contactNum"),
    @NamedQuery(name = "Computers.findByDateMod", query = "SELECT c FROM Computers c WHERE c.dateMod = :dateMod"),
    @NamedQuery(name = "Computers.findByOs", query = "SELECT c FROM Computers c WHERE c.os = :os"),
    @NamedQuery(name = "Computers.findByOsver", query = "SELECT c FROM Computers c WHERE c.osver = :osver"),
    @NamedQuery(name = "Computers.findByTimestamp", query = "SELECT c FROM Computers c WHERE c.timestamp = :timestamp"),
    @NamedQuery(name = "Computers.findByReserv", query = "SELECT c FROM Computers c WHERE c.reserv = :reserv"),
    @NamedQuery(name = "Computers.findByMonFqdn", query = "SELECT c FROM Computers c WHERE c.monFqdn = :monFqdn"),
    @NamedQuery(name = "Computers.findByMonServer", query = "SELECT c FROM Computers c WHERE c.monServer = :monServer"),
    @NamedQuery(name = "Computers.findByColor", query = "SELECT c FROM Computers c WHERE c.color = :color"),
    @NamedQuery(name = "Computers.findByIrdDate", query = "SELECT c FROM Computers c WHERE c.irdDate = :irdDate"),
    @NamedQuery(name = "Computers.findByIrdStatus", query = "SELECT c FROM Computers c WHERE c.irdStatus = :irdStatus"),
    @NamedQuery(name = "Computers.findByDevtypeId", query = "SELECT c FROM Computers c WHERE c.devtypeId = :devtypeId"),
    @NamedQuery(name = "Computers.findByInvSup", query = "SELECT c FROM Computers c WHERE c.invSup = :invSup"),
    @NamedQuery(name = "Computers.findByCarePack", query = "SELECT c FROM Computers c WHERE c.carePack = :carePack")})
public class Computers implements Serializable, Comparable<Computers> {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @Size(max = 200)
    @Column(name = "name")
    private String name;
    @Size(max = 200)
    @Column(name = "acc_name")
    private String accName;
    @Size(max = 200)
    @Column(name = "serial")
    private String serial;
    @Size(max = 200)
    @Column(name = "inv_number")
    private String invNumber;
    @Size(max = 200)
    @Column(name = "old_inv_number")
    private String oldInvNumber;
    @Size(max = 200)
    @Column(name = "hosting_number")
    private String hostingNumber;
    @Lob
    @Size(max = 16777215)
    @Column(name = "comments")
    private String comments;
    @Column(name = "lease_expired")
    @Temporal(TemporalType.DATE)
    private Date leaseExpired;
    @Size(max = 90)
    @Column(name = "contact")
    private String contact;
    @Lob
    @Size(max = 16777215)
    @Column(name = "ip")
    private String ip;
    @Column(name = "rack_unit")
    private Integer rackUnit;
    @Column(name = "box_unit")
    private Integer boxUnit;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "cost")
    private BigDecimal cost;
    @Column(name = "buy_date")
    @Temporal(TemporalType.DATE)
    private Date buyDate;
    @Lob
    @Size(max = 16777215)
    @Column(name = "network")
    private String network;
    @Size(max = 30)
    @Column(name = "mb_manufact")
    private String mbManufact;
    @Size(max = 90)
    @Column(name = "mb_type")
    private String mbType;
    @Size(max = 30)
    @Column(name = "mb_sn")
    private String mbSn;
    @Size(max = 100)
    @Column(name = "cpu")
    private String cpu;
    @Size(max = 30)
    @Column(name = "cpu_speed")
    private String cpuSpeed;
    @Column(name = "cpu_pn")
    private BigInteger cpuPn;
    @Column(name = "psu_pn")
    private Integer psuPn;
    @Size(max = 6)
    @Column(name = "ram")
    private String ram;
    @Column(name = "guarantee")
    @Temporal(TemporalType.DATE)
    private Date guarantee;
    @Column(name = "port_connected1")
    private Short portConnected1;
    @Column(name = "switch_connected_id")
    private Integer switchConnectedId;
    @Size(max = 90)
    @Column(name = "contact_num")
    private String contactNum;
    @Column(name = "date_mod")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateMod;
    @Lob
    @Size(max = 16777215)
    @Column(name = "accounts_doc")
    private String accountsDoc;
    @Size(max = 100)
    @Column(name = "os")
    private String os;
    @Size(max = 100)
    @Column(name = "osver")
    private String osver;
    @Basic(optional = false)
    @NotNull
    @Column(name = "timestamp")
    @Temporal(TemporalType.TIMESTAMP)
    private Date timestamp;
    @Column(name = "reserv")
    private Boolean reserv;
    @Size(max = 255)
    @Column(name = "mon_fqdn")
    private String monFqdn;
    @Size(max = 255)
    @Column(name = "mon_server")
    private String monServer;
    @Size(max = 5)
    @Column(name = "color")
    private String color;
    @Column(name = "ird_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date irdDate;
    @Size(max = 20)
    @Column(name = "ird_status")
    private String irdStatus;
    @Column(name = "devtype_id")
    private Integer devtypeId;
    @Size(max = 10)
    @Column(name = "inv_sup")
    private String invSup;
    @Size(max = 13)
    @Column(name = "care_pack")
    private String carePack;
    @Lob
    @Size(max = 16777215)
    @Column(name = "ipmi")
    private String ipmi;

    @ManyToOne(fetch=FetchType.EAGER)
    @JoinColumn(name="group_id", insertable=false, updatable=false)
    private Groups group;
    
    @ManyToOne(fetch=FetchType.EAGER)
    @JoinColumn(name="rack_id", insertable=false, updatable=false)
    private Racks rack;
    
    @ManyToOne(fetch=FetchType.EAGER)
    @JoinColumn(name="status_id", insertable=false, updatable=false)
    private ComputerStatus status;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "model_id", insertable = false, updatable = false)
    private Models model;
    
    public Computers() {
    }

    public Computers(Integer id) {
        this.id = id;
    }

    public Computers(Integer id, Date timestamp) {
        this.id = id;
        this.timestamp = timestamp;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAccName() {
        return accName;
    }

    public void setAccName(String accName) {
        this.accName = accName;
    }

    public String getSerial() {
        return serial;
    }

    public void setSerial(String serial) {
        this.serial = serial;
    }

    public String getInvNumber() {
        return invNumber;
    }

    public void setInvNumber(String invNumber) {
        this.invNumber = invNumber;
    }

    public String getOldInvNumber() {
        return oldInvNumber;
    }

    public void setOldInvNumber(String oldInvNumber) {
        this.oldInvNumber = oldInvNumber;
    }

    public String getHostingNumber() {
        return hostingNumber;
    }

    public void setHostingNumber(String hostingNumber) {
        this.hostingNumber = hostingNumber;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Date getLeaseExpired() {
        return leaseExpired;
    }

    public void setLeaseExpired(Date leaseExpired) {
        this.leaseExpired = leaseExpired;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public Integer getRackUnit() {
        return rackUnit;
    }

    public void setRackUnit(Integer rackUnit) {
        this.rackUnit = rackUnit;
    }

    public Integer getBoxUnit() {
        return boxUnit;
    }

    public void setBoxUnit(Integer boxUnit) {
        this.boxUnit = boxUnit;
    }

    public BigDecimal getCost() {
        return cost;
    }

    public void setCost(BigDecimal cost) {
        this.cost = cost;
    }

    public Date getBuyDate() {
        return buyDate;
    }

    public void setBuyDate(Date buyDate) {
        this.buyDate = buyDate;
    }

    public String getNetwork() {
        return network;
    }

    public void setNetwork(String network) {
        this.network = network;
    }

    public String getMbManufact() {
        return mbManufact;
    }

    public void setMbManufact(String mbManufact) {
        this.mbManufact = mbManufact;
    }

    public String getMbType() {
        return mbType;
    }

    public void setMbType(String mbType) {
        this.mbType = mbType;
    }

    public String getMbSn() {
        return mbSn;
    }

    public void setMbSn(String mbSn) {
        this.mbSn = mbSn;
    }

    public String getCpu() {
        return cpu;
    }

    public void setCpu(String cpu) {
        this.cpu = cpu;
    }

    public String getCpuSpeed() {
        return cpuSpeed;
    }

    public void setCpuSpeed(String cpuSpeed) {
        this.cpuSpeed = cpuSpeed;
    }

    public BigInteger getCpuPn() {
        return cpuPn;
    }

    public void setCpuPn(BigInteger cpuPn) {
        this.cpuPn = cpuPn;
    }

    public Integer getPsuPn() {
        return psuPn;
    }

    public void setPsuPn(Integer psuPn) {
        this.psuPn = psuPn;
    }

    public String getRam() {
        return ram;
    }

    public void setRam(String ram) {
        this.ram = ram;
    }

    public Date getGuarantee() {
        return guarantee;
    }

    public void setGuarantee(Date guarantee) {
        this.guarantee = guarantee;
    }

    public Short getPortConnected1() {
        return portConnected1;
    }

    public void setPortConnected1(Short portConnected1) {
        this.portConnected1 = portConnected1;
    }

    public Integer getSwitchConnectedId() {
        return switchConnectedId;
    }

    public void setSwitchConnectedId(Integer switchConnectedId) {
        this.switchConnectedId = switchConnectedId;
    }

    public String getContactNum() {
        return contactNum;
    }

    public void setContactNum(String contactNum) {
        this.contactNum = contactNum;
    }

    public Date getDateMod() {
        return dateMod;
    }

    public void setDateMod(Date dateMod) {
        this.dateMod = dateMod;
    }

    public String getAccountsDoc() {
        return accountsDoc;
    }

    public void setAccountsDoc(String accountsDoc) {
        this.accountsDoc = accountsDoc;
    }

    public String getOs() {
        return os;
    }

    public void setOs(String os) {
        this.os = os;
    }

    public String getOsver() {
        return osver;
    }

    public void setOsver(String osver) {
        this.osver = osver;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public Boolean getReserv() {
        return reserv;
    }

    public void setReserv(Boolean reserv) {
        this.reserv = reserv;
    }

    public String getMonFqdn() {
        return monFqdn;
    }

    public void setMonFqdn(String monFqdn) {
        this.monFqdn = monFqdn;
    }

    public String getMonServer() {
        return monServer;
    }

    public void setMonServer(String monServer) {
        this.monServer = monServer;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Date getIrdDate() {
        return irdDate;
    }

    public void setIrdDate(Date irdDate) {
        this.irdDate = irdDate;
    }

    public String getIrdStatus() {
        return irdStatus;
    }

    public void setIrdStatus(String irdStatus) {
        this.irdStatus = irdStatus;
    }

    public Integer getDevtypeId() {
        return devtypeId;
    }

    public void setDevtypeId(Integer devtypeId) {
        this.devtypeId = devtypeId;
    }

    public String getInvSup() {
        return invSup;
    }

    public void setInvSup(String invSup) {
        this.invSup = invSup;
    }

    public String getCarePack() {
        return carePack;
    }

    public void setCarePack(String carePack) {
        this.carePack = carePack;
    }

    public String getIpmi() {
        return ipmi;
    }

    public void setIpmi(String ipmi) {
        this.ipmi = ipmi;
    }

    public Groups getGroup() {
        return group;
    }

    public void setGroup(Groups group) {
        this.group = group;
    }

    public Racks getRack() {
        return rack;
    }

    public void setRack(Racks rack) {
        this.rack = rack;
    }

    public ComputerStatus getStatus() {
        return status;
    }

    public void setStatus(ComputerStatus status) {
        this.status = status;
    }

    public Models getModel() {
        return model;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Computers)) {
            return false;
        }
        Computers other = (Computers) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return this.name;
    }
    
    @Override 
    public int compareTo(Computers computer) {
        if (!this.name.isEmpty()) {
            return this.name.compareTo(rack.getName());
        }
        
        if ((this.invNumber!=null) || (computer.getInvNumber()!=null)) {
            return this.invNumber.compareTo(computer.getInvNumber());
        }
        
        if ((this.serial!=null) || (computer.getSerial()!=null)) {
            return this.serial.compareTo(computer.getSerial());
        }
        
        return 0;
    }
}

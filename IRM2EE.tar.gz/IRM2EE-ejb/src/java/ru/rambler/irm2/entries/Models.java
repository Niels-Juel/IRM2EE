/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.rambler.irm2.entries;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author a.shalin
 */
@Entity
@Table(name = "models")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Models.findAll", query = "SELECT m FROM Models m ORDER BY m.name"),
    @NamedQuery(name = "Models.findById", query = "SELECT m FROM Models m WHERE m.id = :id"),
    @NamedQuery(name = "Models.findByName", query = "SELECT m FROM Models m WHERE m.name = :name"),
    @NamedQuery(name = "Models.findByPsuCount", query = "SELECT m FROM Models m WHERE m.psuCount = :psuCount"),
    @NamedQuery(name = "Models.findByPower", query = "SELECT m FROM Models m WHERE m.power = :power"),
    @NamedQuery(name = "Models.findByCode", query = "SELECT m FROM Models m WHERE m.code = :code"),
    @NamedQuery(name = "Models.findByPartNumber", query = "SELECT m FROM Models m WHERE m.partNumber = :partNumber")})
public class Models implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Size(max = 255)
    @Column(name = "name")
    private String name;
    @Lob
    @Size(max = 65535)
    @Column(name = "description")
    private String description;
    @Column(name = "psu_count")
    private Integer psuCount;
    @Column(name = "power")
    private Integer power;
    @Size(max = 255)
    @Column(name = "code")
    private String code;
    @Size(max = 11)
    @Column(name = "part_number")
    private String partNumber;
    
    @Column(name = "type_id")
    private Integer typeId;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "type_id", insertable = false, updatable = false)
    private ModelTypes modelType;

    public Models() {
    }

    public Models(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getPsuCount() {
        return psuCount;
    }

    public void setPsuCount(Integer psuCount) {
        this.psuCount = psuCount;
    }

    public Integer getPower() {
        return power;
    }

    public void setPower(Integer power) {
        this.power = power;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public ModelTypes getModelType() {
        return modelType;
    }

    public Integer getTypeId() {
        return typeId;
    }

    public void setTypeId(Integer typeId) {
        this.typeId = typeId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Models)) {
            return false;
        }
        Models other = (Models) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "irm2.entries.Models[ id=" + id + " ]";
    }
    
}

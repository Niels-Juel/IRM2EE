/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ru.rambler.irm2.entries;

import java.io.Serializable;
import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author a.shalin
 */
@Entity
@Table(name = "manufacturers")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Manufacturers.findAll", query = "SELECT m FROM Manufacturers m"),
    @NamedQuery(name = "Manufacturers.findById", query = "SELECT m FROM Manufacturers m WHERE m.id = :id"),
    @NamedQuery(name = "Manufacturers.findByName", query = "SELECT m FROM Manufacturers m WHERE m.name = :name"),
    @NamedQuery(name = "Manufacturers.findByNames", query = "SELECT m FROM Manufacturers m WHERE m.name IN :names"),
    @NamedQuery(name = "Manufacturers.findByUrl", query = "SELECT m FROM Manufacturers m WHERE m.url = :url"),
    @NamedQuery(name = "Manufacturers.findByFullName", query = "SELECT m FROM Manufacturers m WHERE m.fullName = :fullName"),
    @NamedQuery(name = "Manufacturers.findByPhone", query = "SELECT m FROM Manufacturers m WHERE m.phone = :phone"),
    @NamedQuery(name = "Manufacturers.findBySupportEmail", query = "SELECT m FROM Manufacturers m WHERE m.supportEmail = :supportEmail"),
    @NamedQuery(name = "Manufacturers.findByAddress", query = "SELECT m FROM Manufacturers m WHERE m.address = :address")})
public class Manufacturers implements Serializable, Comparable<Manufacturers> {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "name")
    private String name;
    @Column(name = "url")
    private String url;
    @Column(name = "full_name")
    private String fullName;
    @Column(name = "phone")
    private String phone;
    @Column(name = "support_email")
    private String supportEmail;
    @Column(name = "address")
    private String address;
    
    public Manufacturers() {
    }

    public Manufacturers(Integer id) {
        this.id = id;
    }

    public Manufacturers(Integer id, String name) {
        this.id = id;
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getSupportEmail() {
        return supportEmail;
    }

    public void setSupportEmail(String supportEmail) {
        this.supportEmail = supportEmail;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Manufacturers)) {
            return false;
        }
        Manufacturers other = (Manufacturers) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return this.name;
    }
    
    @Override 
    public int compareTo(Manufacturers manufacturer) {
        return this.name.compareTo(manufacturer.getName());
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ru.rambler.irm2.entries;

import java.util.*;

/**
 *
 * @author a.shalin
 */
public class DiskStore {
    private String name, goodDisksCriteria, email;
    private List<Integer> trashCan;
    private List<Integer> boxes;
    
    public DiskStore() {
        name=null;
        trashCan=null;
        goodDisksCriteria=null;
        email=null;
    }
    
    public DiskStore(String name, List<Integer> trashCan, String goodDisksCriteria, String email) {
        this.name=name;
        this.trashCan=trashCan;
        this.goodDisksCriteria=goodDisksCriteria;
        this.email=email;
    }
    
    public DiskStore(String name, List<Integer> trashCan, List<Integer> boxes, String email) {
        this.name=name;
        this.trashCan=trashCan;
        this.boxes=boxes;
        this.email=email;
    }

    public List<Integer> getBoxes() {
        return boxes;
    }

    public void setBoxes(List<Integer> boxes) {
        this.boxes = boxes;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGoodDisksCriteria() {
        return goodDisksCriteria;
    }

    public void setGoodDisksCriteria(String goodDisksCriteria) {
        this.goodDisksCriteria = goodDisksCriteria;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<Integer> getTrashCan() {
        return trashCan;
    }

    public void setTrashCan(List<Integer> trashCan) {
        this.trashCan = trashCan;
    }
}

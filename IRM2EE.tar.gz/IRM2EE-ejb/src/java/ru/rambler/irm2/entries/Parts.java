/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ru.rambler.irm2.entries;

import java.io.Serializable;
import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author a.shalin
 */
@Entity
@Table(name = "parts")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Parts.findAll", query = "SELECT p FROM Parts p"),
    @NamedQuery(name = "Parts.findById", query = "SELECT p FROM Parts p WHERE p.id = :id"),
    @NamedQuery(name = "Parts.findByName", query = "SELECT p FROM Parts p WHERE UPPER(p.name) = :name"),
    @NamedQuery(name = "Parts.findByTypes", query = "SELECT p FROM Parts p WHERE p.partType.name IN :types"),
    @NamedQuery(name = "Parts.findByManufName", query = "SELECT p FROM Parts p WHERE p.manufacturer.name = :name"),
    @NamedQuery(name = "Parts.findByBarcode", query = "SELECT p FROM Parts p WHERE p.barcode = :barcode")})
public class Parts implements Serializable, Comparable<Parts> {
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    
    @Column(name = "name")
    private String name;
    @Column(name = "barcode")
    private String barcode;
    @Lob
    @Column(name = "picture")
    private byte[] picture;
    @Lob
    @Column(name = "description")
    private String description;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="manufacturer_id")
    private Manufacturers manufacturer;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="type_id")
    private PartTypes partType;
    
    @Column(name = "pn")
    private String partNumber;

    @Transient
    private Integer qnty;
    
    public Parts() {
    }

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public byte[] getPicture() {
        return picture;
    }

    public void setPicture(byte[] picture) {
        this.picture = picture;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Manufacturers getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(Manufacturers manufacturer) {
        this.manufacturer = manufacturer;
    }

    public PartTypes getPartType() {
        return partType;
    }

    public void setPartType(PartTypes partType) {
        this.partType = partType;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Parts)) {
            return false;
        }
        Parts other = (Parts) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return this.name;
    }
    
    @Override 
    public int compareTo(Parts part) {
        return this.name.compareTo(part.getName());
    }
}

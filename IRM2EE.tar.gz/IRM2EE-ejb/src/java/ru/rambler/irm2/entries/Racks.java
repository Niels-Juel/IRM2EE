/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ru.rambler.irm2.entries;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author a.shalin
 */
@Entity
@Table(name = "racks")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Racks.findAll", query = "SELECT r FROM Racks r"),
    @NamedQuery(name = "Racks.findById", query = "SELECT r FROM Racks r WHERE r.id = :id"),
    @NamedQuery(name = "Racks.findByName", query = "SELECT r FROM Racks r WHERE r.name = :name"),
    @NamedQuery(name = "Racks.findByDepth", query = "SELECT r FROM Racks r WHERE r.depth = :depth"),
    @NamedQuery(name = "Racks.findByHeight", query = "SELECT r FROM Racks r WHERE r.height = :height"),
    @NamedQuery(name = "Racks.findByPower", query = "SELECT r FROM Racks r WHERE r.power = :power"),
    @NamedQuery(name = "Racks.findByPowerSockets", query = "SELECT r FROM Racks r WHERE r.powerSockets = :powerSockets"),
    @NamedQuery(name = "Racks.findByRow", query = "SELECT r FROM Racks r WHERE r.row = :row"),
    @NamedQuery(name = "Racks.findByLocations", query = "SELECT r FROM Racks r WHERE r.location.name IN :locNames"),
    @NamedQuery(name = "Racks.findByCol", query = "SELECT r FROM Racks r WHERE r.col = :col")})
public class Racks implements Serializable, Comparable<Racks> {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Size(max = 7)
    @Column(name = "name")
    private String name;
    @Lob
    @Size(max = 65535)
    @Column(name = "description")
    private String description;
    @Column(name = "depth")
    private Integer depth;
    @Column(name = "height")
    private Integer height;
    @Column(name = "power")
    private Integer power;
    @Column(name = "power_sockets")
    private Integer powerSockets;
    @Column(name = "row")
    private Integer row;
    @Column(name = "col")
    private Integer col;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="location_id", insertable=false, updatable=false)
    private Locations location;
    
    public Racks() {
    }

    public Racks(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getDepth() {
        return depth;
    }

    public void setDepth(Integer depth) {
        this.depth = depth;
    }

    public Integer getHeight() {
        return height;
    }

    public void setHeight(Integer height) {
        this.height = height;
    }

    public Integer getPower() {
        return power;
    }

    public void setPower(Integer power) {
        this.power = power;
    }

    public Integer getPowerSockets() {
        return powerSockets;
    }

    public void setPowerSockets(Integer powerSockets) {
        this.powerSockets = powerSockets;
    }

    public Integer getRow() {
        return row;
    }

    public void setRow(Integer row) {
        this.row = row;
    }

    public Integer getCol() {
        return col;
    }

    public void setCol(Integer col) {
        this.col = col;
    }

    public Locations getLocation() {
        return location;
    }

    public void setLocation(Locations location) {
        this.location = location;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Racks)) {
            return false;
        }
        Racks other = (Racks) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return this.name;
    }
    
    @Override 
    public int compareTo(Racks rack) {
        return this.name.compareTo(rack.getName());
    }
}

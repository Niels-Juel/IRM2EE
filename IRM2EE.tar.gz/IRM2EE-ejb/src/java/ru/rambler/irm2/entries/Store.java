/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ru.rambler.irm2.entries;

import java.io.Serializable;
import java.util.Calendar;
import javax.persistence.*;

/**
 *
 * @author a.shalin
 */
@Entity
@Table (name="store")
@NamedQueries({
    @NamedQuery(name = "Store.findAll", query = "SELECT s FROM Store s"),
    @NamedQuery(name = "Store.findById", query = "SELECT s FROM Store s WHERE s.id = :id"),
    @NamedQuery(name = "Store.findBySerial", query = "SELECT s FROM Store s WHERE s.serial = :serial"),
    @NamedQuery(name = "Store.findBySerials", query = "SELECT s FROM Store s WHERE s.serial IN :serials"),
    @NamedQuery(name = "Store.findByPartName", query = "SELECT s FROM Store s WHERE s.part.name = :name"),
    @NamedQuery(name = "Store.findByPartNames", query = "SELECT s FROM Store s WHERE s.part.name IN :names"),
    @NamedQuery(name = "Store.findByManufName", query = "SELECT s FROM Store s WHERE s.part.manufacturer.name = :name"),
    @NamedQuery(name = "Store.findInBoxes", query = "SELECT s FROM Store s WHERE s.box.id IN :boxes")
})
public class Store implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name="id")
    private Integer id;
    
    @Basic(optional = false)
    @Column(name="serial", nullable = false)
    private String serial;
    
    @Column(name="st_timestamp")
    @Temporal(TemporalType.TIMESTAMP)
    private java.util.Calendar st_timestamp;
    
    @Basic(optional = true)
    @Column(name="computer_id")
    private Integer computer_id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "part_id", insertable = false, updatable = false)
    private Parts part;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "box_id", insertable = false, updatable = false)
    private Boxes box;
    
    @Basic(optional = true)
    @Column(name="box_id")
    private Integer boxId;

    public Calendar getSt_timestamp() {
        return st_timestamp;
    }

    public void setSt_timestamp(Calendar st_timestamp) {
        this.st_timestamp = st_timestamp;
    }

    public Integer getComputer_id() {
        return computer_id;
    }

    public void setComputer_id(Integer computer_id) {
        this.computer_id = computer_id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSerial() {
        return serial;
    }

    public void setSerial(String serial) {
        this.serial = serial;
    }

    public Parts getPart() {
        return part;
    }

    public void setPart(Parts part) {
        this.part = part;
    }

    public Boxes getBox() {
        return box;
    }

    public void setBox(Boxes box) {
        this.box = box;
    }

    public Integer getBoxId() {
        return boxId;
    }

    public void setBoxId(Integer boxId) {
        this.boxId = boxId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Store)) {
            return false;
        }
        Store other = (Store) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "jpatest.entities.NewEntity[ id=" + id + " ]";
    }
    
}

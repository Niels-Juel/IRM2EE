/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.rambler.irm2.entries;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author a.shalin
 */
@Entity
@Table(name = "model_parts")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ModelParts.findAll", query = "SELECT m FROM ModelParts m"),
    @NamedQuery(name = "ModelParts.findById", query = "SELECT m FROM ModelParts m WHERE m.id = :id"),
    @NamedQuery(name = "ModelParts.findByQty", query = "SELECT m FROM ModelParts m WHERE m.qty = :qty")})
public class ModelParts implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Column(name = "qty")
    private int qty;
    
    @NotNull
    @Column(name="model_id")
    private Integer modelId;
    
    @NotNull
    @Column(name="part_id")
    private Integer partId;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "part_id", insertable = false, updatable = false)
    private Parts part;

    public ModelParts() {
    }

    public ModelParts(Integer id) {
        this.id = id;
    }

    public ModelParts(Integer id, int qty) {
        this.id = id;
        this.qty = qty;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public Parts getPart() {
        return part;
    }

    public Integer getModelId() {
        return modelId;
    }

    public void setModelId(Integer modelId) {
        this.modelId = modelId;
    }

    public Integer getPartId() {
        return partId;
    }

    public void setPartId(Integer partId) {
        this.partId = partId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ModelParts)) {
            return false;
        }
        ModelParts other = (ModelParts) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "irm2.entries.ModelParts[ id=" + id + " ]";
    }
    
}

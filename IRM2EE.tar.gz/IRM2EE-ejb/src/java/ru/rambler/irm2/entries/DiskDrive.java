/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ru.rambler.irm2.entries;

import ru.rambler.irm2.entries.Parts;

/**
 *
 * @author a.shalin
 */
public class DiskDrive {
    private String name, manufacturer, description;
    private Parts part;
    private int quantity, id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Parts getPart() {
        return part;
    }

    public void setPart(Parts part) {
        this.part = part;
    }
    
    public DiskDrive() {
        quantity=0;
    }    
    
    public DiskDrive(String name, String manufacturer, String description) {
        this.quantity=0;
        this.name=name;
        this.manufacturer=manufacturer;
        this.description=description;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.rambler.irm2.entries;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author a.shalin
 */
@Entity
@Table(name = "replaces")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Replaces.findAll", query = "SELECT r FROM Replaces r"),
    @NamedQuery(name = "Replaces.findById", query = "SELECT r FROM Replaces r WHERE r.id = :id"),
    @NamedQuery(name = "Replaces.findByDate", query = "SELECT r FROM Replaces r WHERE r.date = :date"),
    @NamedQuery(name = "Replaces.findByUser", query = "SELECT r FROM Replaces r WHERE r.user = :user")})
public class Replaces implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    
    @Basic(optional = false)
    @NotNull
    @Column(name = "date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date date;

    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "user")
    private String user;
    
    @Basic(optional = true)
    @Column(name="remove_id")
    private Integer removeId;
    
    @Basic(optional = true)
    @Column(name="add_id")
    private Integer addId;
    
    @Basic(optional = true)
    @Column(name="computer_id")
    private Integer computerId;
    
    @ManyToOne
    @JoinColumn(name = "computer_id", insertable=false, updatable=false)
    private Computers computer;

    public Replaces() {
    }

    public Replaces(Integer id) {
        this.id = id;
    }

    public Replaces(Integer id, Date date, String user) {
        this.id = id;
        this.date = date;
        this.user = user;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public Integer getRemoveId() {
        return removeId;
    }

    public void setRemoveId(Integer removeId) {
        this.removeId = removeId;
    }

    public Integer getAddId() {
        return addId;
    }

    public void setAddId(Integer addId) {
        this.addId = addId;
    }

    public Integer getComputerId() {
        return computerId;
    }

    public void setComputerId(Integer computerId) {
        this.computerId = computerId;
    }

    public Computers getComputer() {
        return computer;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Replaces)) {
            return false;
        }
        Replaces other = (Replaces) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "irm2.entries.Replaces[ id=" + id + " ]";
    }
    
}

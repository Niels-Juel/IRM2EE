/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.rambler.irm2.entries;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author a.shalin
 */
@Entity
@Table(name = "purchases", catalog = "irmdb", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Purchases.findAll", query = "SELECT p FROM Purchases p"),
    @NamedQuery(name = "Purchases.findById", query = "SELECT p FROM Purchases p WHERE p.id = :id"),
    @NamedQuery(name = "Purchases.findByPurchType", query = "SELECT p FROM Purchases p WHERE p.purchType = :purchType"),
    @NamedQuery(name = "Purchases.findByModel", query = "SELECT p FROM Purchases p WHERE p.model = :model"),
    @NamedQuery(name = "Purchases.findByQuantity", query = "SELECT p FROM Purchases p WHERE p.quantity = :quantity"),
    @NamedQuery(name = "Purchases.findByOrderDate", query = "SELECT p FROM Purchases p WHERE p.orderDate = :orderDate"),
    @NamedQuery(name = "Purchases.findByDeliveryDate", query = "SELECT p FROM Purchases p WHERE p.deliveryDate = :deliveryDate"),
    @NamedQuery(name = "Purchases.findByCost", query = "SELECT p FROM Purchases p WHERE p.cost = :cost"),
    @NamedQuery(name = "Purchases.findByVendor", query = "SELECT p FROM Purchases p WHERE p.vendor = :vendor"),
    @NamedQuery(name = "Purchases.findByProject", query = "SELECT p FROM Purchases p WHERE p.project = :project")})
public class Purchases implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", updatable = false)
    private Integer id;
    @Size(max = 255)
    @Column(name = "purch_type")
    private String purchType;
    @Size(max = 255)
    @Column(name = "model")
    private String model;
    @Column(name = "quantity")
    private Integer quantity;
    @Basic(optional = false)
    @NotNull
    @Column(name = "order_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date orderDate;
    @Basic(optional = false)
    @NotNull
    @Column(name = "delivery_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deliveryDate;
    // @Max(value=?)  
    @Min(value=0)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "cost")
    private BigDecimal cost;
    @Column(name = "vendor")
    private Integer vendor;
    @Size(max = 255)
    @Column(name = "project")
    private String project;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="status_id", insertable=false, updatable=false)
    private PurchaseStatus status;
    
    @Column(name = "status_id")
    private Integer statusId;
    
    @Transient
    private int index;
    
    public Purchases() {
        this.statusId=1;
        this.orderDate=new Date();
        this.deliveryDate=new Date();
    }

    public Purchases(Integer id) {
        this.id = id;
        this.statusId=1;
        this.orderDate=new Date();
        this.deliveryDate=new Date();
    }

    public Purchases(Integer id, Date orderDate, Date deliveryDate) {
        this.id = id;
        this.orderDate = orderDate;
        this.deliveryDate = deliveryDate;
        this.statusId=1;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPurchType() {
        return purchType;
    }

    public void setPurchType(String purchType) {
        this.purchType = purchType;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    public Date getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(Date deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public BigDecimal getCost() {
        return cost;
    }

    public void setCost(BigDecimal cost) {
        this.cost = cost;
    }

    public Integer getVendor() {
        return vendor;
    }

    public void setVendor(Integer vendor) {
        this.vendor = vendor;
    }

    public String getProject() {
        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    public PurchaseStatus getStatus() {
        return status;
    }

    public Integer getStatusId() {
        return statusId;
    }

    public void setStatusId(Integer statusId) {
        this.statusId = statusId;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Purchases)) {
            return false;
        }
        Purchases other = (Purchases) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ru.rambler.irm2.entries.Purchases[ id=" + id + " ]";
    }
}

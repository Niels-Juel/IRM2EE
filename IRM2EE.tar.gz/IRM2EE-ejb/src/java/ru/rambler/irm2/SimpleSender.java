/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ru.rambler.irm2;

import java.util.Properties;
import java.util.Date;

import javax.mail.*;

import javax.mail.internet.*;

import com.sun.mail.smtp.*;

/**
 *
 * @author a.shalin
 */
public class SimpleSender {
    public static void sendMessageViaGmail(String addressFrom, String addressTo, String subject, String bodyMessage) throws MessagingException, AddressException {
        Properties props = System.getProperties();
        props.put("mail.smtps.host","smtp.gmail.com");
        props.put("mail.smtps.auth","true");
        Session session = Session.getInstance(props, null);
        Message msg = new MimeMessage(session);
        msg.setFrom(new InternetAddress(addressFrom));
        msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(addressTo, false));
        msg.setSubject(subject);
        msg.setText(bodyMessage);
        msg.setHeader("X-Mailer", "Tov Are's program");
        msg.setSentDate(new Date());
        SMTPTransport t = (SMTPTransport)session.getTransport("smtps");
        t.connect("smtp.gmail.com", "alex.octabrain@gmail.com", "ForsakenLands32078");
        t.sendMessage(msg, msg.getAllRecipients());
        System.out.println("Response: " + t.getLastServerResponse());
        t.close();
    }
    
    public static void sendMessageViaMailrelay(String addressFrom, String addressTo, String subject, String bodyMessage) throws MessagingException, AddressException {
        Properties props = System.getProperties();
        props.put("mail.smtp.host","mailrelay2.rambler.ru");
        props.put("mail.smtp.auth","false");
        props.put("mail.smtp.port", 25);
        Session session = Session.getInstance(props, null);
        Message msg = new MimeMessage(session);
        msg.setFrom(new InternetAddress(addressFrom));
        msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(addressTo, false));
        msg.setSubject(subject);
        msg.setText(bodyMessage);
        msg.setHeader("X-Mailer", "Tov Are's program");
        msg.setSentDate(new Date());
        SMTPTransport t = (SMTPTransport)session.getTransport("smtp");
//        t.connect("smtp.gmail.com", "alex.octabrain@gmail.com", "ForsakenLands32078");
        t.connect("mailrelay2.rambler.ru", "a.shalin@rambler-co.ru", null);
        t.sendMessage(msg, msg.getAllRecipients());
        System.out.println("Response: " + t.getLastServerResponse());
        t.close();
    }
    
    private SimpleSender() {
    
    }
    
}

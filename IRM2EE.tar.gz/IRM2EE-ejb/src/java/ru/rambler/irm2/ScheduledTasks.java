/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ru.rambler.irm2;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import org.xml.sax.InputSource;
import ru.rambler.irm2.entries.Boxes;
import ru.rambler.irm2.entries.Store;
import ru.rambler.irm2.entries.Parts;
import ru.rambler.irm2.entries.DiskDrive;
import ru.rambler.irm2.entries.DiskStore;
import java.util.*;
import java.util.Map.Entry;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Schedule;
import javax.ejb.Schedules;
import javax.ejb.Stateless;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonValue;
import javax.mail.MessagingException;
import javax.persistence.*;
import javax.xml.bind.*;
import javax.xml.transform.stream.StreamSource;
import org.eclipse.persistence.jaxb.JAXBContextProperties;
import org.eclipse.persistence.jaxb.UnmarshallerProperties;
import org.eclipse.persistence.jaxb.MarshallerProperties;
import ru.rambler.irm2.entries.Computers;

/**
 *
 * @author a.shalin
 */
@Stateless
@LocalBean
public class ScheduledTasks {
    @PersistenceContext(unitName = "IRM2EE-ejbPU")
    private EntityManager entityManager;
    
    @EJB
    private RestApiClient restApiClient;
    
    private Object MarshallerProperties;
    
    private List<DCBoxes> dcBoxes;

    @Deprecated
    private String substitute(String diskDriveName) {
        if (diskDriveName.equalsIgnoreCase("SSDSC2MH250A2K5")) {
            return "INTEL SSDSC2MH250A2";
        }
        return diskDriveName;
    }    
    
    @Deprecated
    public void checkDiskStore() {
        Map<String, DiskStore>locations=new HashMap<>();

        locations.put("EOS", new DiskStore("Комната EOS на Остаповке", Arrays.asList(239), Arrays.asList(166, 268, 134, 292), "eo@rambler-co.ru"));
        locations.put("KUR", new DiskStore("Датацентр Курчатник", Arrays.asList(109), Arrays.asList(312, 165, 57, 180, 322), "eo@rambler-co.ru"));
        
        String listDiskModels=("HUA722010CLA330\n" +
            "HUS723030ALS640\n" +
            "HUA723020ALA640\n" +
            "HTE725050A7E630\n" +
            "ST3250310NS\n" +
            "HUS724040ALS640\n" +
            "HDS721010KLA330\n" +
            "ST31000340NS\n" +
            "HUS723020ALS640\n" +
            "HDS721616PLA380\n"+
            "HUA722050CLA330\n"+
            "HDS728080PLAT20\n"+
            "HDP725025GLA380\n"+
            "HDS728080PLA380\n"+
            "MK2001TRKB\n").toUpperCase();
        String[] diskModels=listDiskModels.split("\\n");
        Map<String, DiskDrive> diskStock=new HashMap<>();
        Map<String, Integer> treshold=new HashMap<>();
        
        for(String diskModel: diskModels) {
            if(diskModel.equals("ST31000340NS")) {
                treshold.put(diskModel, 4);
            } else {
                treshold.put(diskModel, 2);
            }
        }
        
        for (String diskModel: diskModels) {
            Query query = entityManager.createNamedQuery("Parts.findByName").setParameter("name", diskModel).setMaxResults(1);
            
            DiskDrive diskDrive=new DiskDrive();
            diskStock.put(diskModel, diskDrive);
            List<Parts> partList = query.getResultList();
            diskDrive.setPart(partList.get(0));
            diskDrive.setName(diskModel);
        }
        Iterator it = locations.entrySet().iterator();
        while (it.hasNext()) {
            String conclusion; boolean isNeedToMail, isWasteBinFull, isNeedToSupply;
            Map.Entry pairsLocs = (Map.Entry)it.next();
            if (!pairsLocs.getValue().equals("")) {
                conclusion=""; isNeedToMail=false; isWasteBinFull=false; isNeedToSupply=false;

                for (String diskModel: diskModels) {
                    diskStock.get(diskModel).setQuantity(0);
                }
                String locName=(String) pairsLocs.getKey();
                DiskStore location=(DiskStore) pairsLocs.getValue();
                Query query = entityManager.createNamedQuery("Store.findInBoxes").setParameter("boxes", location.getBoxes());
                List<Store> itemList = query.getResultList();
                for (Store storeItem: itemList) {
                    String partName=storeItem.getPart().getName().toUpperCase();
                    if(diskStock.containsKey(partName)) {
                        diskStock.get(partName).setQuantity(diskStock.get(partName).getQuantity()+1);
                    } else {
//                        System.out.println(partName+" isn't listed!");
                    }
                }

                Iterator stockIterator=diskStock.entrySet().iterator();
                while(stockIterator.hasNext()) {
                    Map.Entry pairsStock = (Map.Entry)stockIterator.next();
                    if (!pairsStock.getValue().equals("")) {
                        String diskName=substitute((String) pairsStock.getKey());
                        DiskDrive diskDrive=(DiskDrive) pairsStock.getValue();
                        if(diskDrive.getQuantity()<treshold.get(diskDrive.getName())) {
                            isNeedToMail=true; isNeedToSupply=true;
                            conclusion+=(diskDrive.getPart().getManufacturer().getName()+" "+diskName+" "+diskDrive.getPart().getDescription()
                                    +"-"+(treshold.get(diskDrive.getName())-diskDrive.getQuantity())+" шт.\n");
                        }
                    }
                }
                
                if (isNeedToSupply) {
                    conclusion="\nНеобходимо восполнить запас дисков в "+location.getName()+"\n"+conclusion;
                }
                
                for(int trashCan: location.getTrashCan()) {
                    query = entityManager.createNamedQuery("Store.findInBoxes").setParameter("boxes", Arrays.asList(trashCan));
                    itemList = query.getResultList();  
                    int wastedDisks=0; 
                    Boxes box = entityManager.find(Boxes.class, trashCan);
                    String trashCanName=box.getName();
                    for (Store item: itemList) {
                        wastedDisks++;
                    }
                    if (wastedDisks>18) {
                        isNeedToMail=true; isWasteBinFull=true;
                        conclusion+=("\nКоробка "+trashCanName+" содержит "+wastedDisks+" дисков на тесты.\n");
                    }
                }
                
                if (isNeedToMail) {
                    conclusion="Обратите внимание: \n"+conclusion;
                    System.out.println(conclusion);
                    try {
                        System.out.println(conclusion);
                        SimpleSender.sendMessageViaMailrelay("a.shalin@rambler-co.ru", location.getEmail(), "Запас дисков в "+location.getName(), 
                                conclusion);
                    } catch (javax.mail.MessagingException ex) {
                        ex.printStackTrace();
                    }
                } else {
                    try {
                        SimpleSender.sendMessageViaMailrelay("a.shalin@rambler-co.ru", "eo.team@rambler-co.ru", "Запас дисков в "+location.getName(), 
                                "С запасом дисков всё ОК");
                    } catch (javax.mail.MessagingException ex) {
                        ex.printStackTrace();
                    }                
                }
            }
        }      
    }
    
    @Schedules({
        @Schedule(hour="9", minute="0", dayOfWeek="Mon"),
        @Schedule(hour="17", minute="0", dayOfWeek="Thu")
    }) 
    public void verifyDiskStore() {
        try {
            scanDatabase();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void checkServers() {
    
    }
    
    private void scanDatabase() throws JAXBException, MessagingException {
        unmarshalParams();
        
        String addressFrom="a.shalin@rambler-co.ru", addressToTask="eo.team@rambler-co.ru", addressToDud="eo.team@rambler-co.ru";
        
        for (DCBoxes dcBox: dcBoxes) {
            boolean isNeedToSupply=false, isOk=true; int wastedDisks=0; String conclusion="";
            
            //Disks supply
            Query query=entityManager.createNamedQuery("Store.findInBoxes").setParameter("boxes", dcBox.getBoxes());
            List<Store> goodDisks=query.getResultList(); Map<String, Integer> actualDisks=new HashMap<>();
            for (Entry<String, Integer> entry: dcBox.getDisks().entrySet()) {
                actualDisks.put(entry.getKey(), 0);
            }
            for (Store diskEntry: goodDisks) {
                if (actualDisks.containsKey(diskEntry.getPart().getName())) {
                    actualDisks.put(diskEntry.getPart().getName(),actualDisks.get(diskEntry.getPart().getName())+1);
                }
            }
            String neededDisks="";
            for (Entry<String, Integer> entry: dcBox.getDisks().entrySet()) {
                String key=entry.getKey();
                if (actualDisks.get(key)<dcBox.getDisks().get(key)) {
                    isNeedToSupply=true; isOk=false;
                    neededDisks+=(key+"-"+(dcBox.getDisks().get(key)-actualDisks.get(key))+" шт.\n");
                }
            }
            if (isNeedToSupply) conclusion+=("Необходимо восполнить запас дисков в "+dcBox.getName()+":\n\n"+neededDisks+"\n");
            
            //Bad disks
            query=entityManager.createNamedQuery("Store.findInBoxes").setParameter("boxes", dcBox.getBadBoxes());
            wastedDisks=query.getResultList().size();
            if (wastedDisks>=20) {
                conclusion+=("В коробках находится "+wastedDisks+" дисков на тестирование.");
                isOk=false;
            }
            
            if (isOk) {
                conclusion="На площадке всё Ок.";
                SimpleSender.sendMessageViaMailrelay(addressFrom, addressToDud, "Запас дисков в "+dcBox.getName(), conclusion);
            } else {
                SimpleSender.sendMessageViaMailrelay(addressFrom, addressToTask, "Запас дисков в "+dcBox.getName(), conclusion);
            }
        }
    }
    
    private void unmarshalParams() throws JAXBException {
//        try (FileInputStream is = new FileInputStream("src/blog/jsonp/moxy/input.json")) {
//        String filePath =Thread.currentThread().getContextClassLoader().getResource("/ru/rambler/irm2/watched_disks.json").getFile();
//        File file = new File(filePath);
//        System.out.println(file.toURI());
//        StreamSource json = new StreamSource(file);

        // Create the EclipseLink JAXB (MOXy) Unmarshaller
        Map<String, Object> jaxbProperties = new HashMap<String, Object>(2);
        jaxbProperties.put(UnmarshallerProperties.MEDIA_TYPE, "application/json");
        jaxbProperties.put(UnmarshallerProperties.JSON_INCLUDE_ROOT, false);
        JAXBContext jc = JAXBContext.newInstance(new Class[] {DCBoxes.class}, jaxbProperties);
        Unmarshaller unmarshaller = jc.createUnmarshaller();

        // Parse the JSON
        ClassLoader loader = ScheduledTasks.class.getClassLoader(); 
        InputStream inputStream = loader.getResourceAsStream("/ru/rambler/irm2/conf/watched_disks.json");
        JsonReader jsonReader = Json.createReader(inputStream);

//        Unmarshal Root Level JsonArray
        JsonArray dcArray = jsonReader.readArray(); //System.out.println(customersArray.size());
        
        //Begin ---------- Dirty hack
        dcBoxes=new ArrayList<>();
        
        for (JsonValue jsonValue: dcArray) {
            DCBoxes dcBox=new DCBoxes();
            dcBox.setName(((JsonObject) jsonValue).getString("name"));
            
            List<Integer> boxes=new ArrayList<Integer>();
            for (JsonValue boxId: ((JsonObject) jsonValue).getJsonArray("boxes")) {
                boxes.add(Integer.parseInt(boxId.toString()));
            }
            dcBox.setBoxes(boxes);
            
            List<Integer> badBoxes=new ArrayList<Integer>();
            for (JsonValue boxId: ((JsonObject) jsonValue).getJsonArray("badBoxes")) {
                badBoxes.add(Integer.parseInt(boxId.toString()));
            }
            dcBox.setBadBoxes(badBoxes);
            
            Map<String, Integer> disks=new HashMap<>();
            JsonObject jsonDisksMap=((JsonObject) jsonValue).getJsonObject("disks");
            JsonArray jsonDisks=((JsonObject) jsonDisksMap).getJsonArray("entry");
            for (JsonValue jsonDisk: jsonDisks) {
                String key=((JsonObject) jsonDisk).getString("key");
                Integer value=((JsonObject) jsonDisk).getInt("value");
                disks.put(key, value);
            }
            dcBox.setDisks(disks);
            
            dcBoxes.add(dcBox);
        }
        //End ----------- Dirty hack
        
//        JsonStructureSource arraySource = new JsonStructureSource(customersArray);
//        dcBoxes = (List<DCBoxes>) unmarshaller.unmarshal(arraySource, DCBoxes.class).getValue();
//        for(DCBoxes dcBox : dcBoxes) {
//            System.out.println(dcBox.getName());
//        }

        // Unmarshal Nested JsonObject
//        JsonObject customerObject = customersArray.getJsonObject(1);
//        JsonStructureSource objectSource = new JsonStructureSource(customerObject);
//        DCBoxes customer = unmarshaller.unmarshal(objectSource, DCBoxes.class).getValue();
//        for(PhoneNumber phoneNumber : customer.getPhoneNumbers()) {
//            System.out.println(phoneNumber.getNumber());
//        }
//        }
    }
    
//    private void testUnmarshaller() throws JAXBException {
//        Map<String, Object> properties = new HashMap<>();
//        properties.put(UnmarshallerProperties.MEDIA_TYPE, "application/json");
//        properties.put(UnmarshallerProperties.JSON_INCLUDE_ROOT, false);
//        JAXBContext jc = JAXBContext.newInstance(new Class[] {DCBoxes.class}, properties);
//
//        String filePath =Thread.currentThread().getContextClassLoader().getResource("/ru/rambler/irm2/conf/dud.json").getFile();
//        File file = new File(filePath);        
//        
//        Unmarshaller unmarshaller = jc.createUnmarshaller();
//        StreamSource json = new StreamSource(file);
//        DCBoxes dcBox = unmarshaller.unmarshal(json, DCBoxes.class).getValue();
// 
//        Marshaller marshaller = jc.createMarshaller();
//        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
//        marshaller.marshal(dcBox, System.out);
//    }

    public void testMarshaller() {
        try {
            testPost();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    private void testPost() throws JAXBException, IOException {
        JAXBContext jaxbContext = JAXBContext.newInstance(JiraIssue.class);
        Marshaller marshaller = jaxbContext.createMarshaller();
        
        JiraIssue jiraIssue=new JiraIssue();
        jiraIssue.getFields().setSummary("Test issue");
        jiraIssue.getFields().setDescription("Testing issue creating!");
        jiraIssue.getFields().getProject().setId("11901");
        jiraIssue.getFields().getIssueType().setId("1");
        
        OutputStream outputStream = new OutputStream() {
            private StringBuilder string = new StringBuilder();
            @Override
            public void write(int b) throws IOException {
                this.string.append((char) b );
            }

            //Netbeans IDE automatically overrides this toString()
            public String toString(){
                System.out.println(this.string.toString());
                return this.string.toString();
            }
        };
        
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        marshaller.setProperty(org.eclipse.persistence.jaxb.MarshallerProperties.MEDIA_TYPE, "application/json");
        marshaller.setProperty(org.eclipse.persistence.jaxb.MarshallerProperties.JSON_INCLUDE_ROOT, false);
        marshaller.marshal(jiraIssue, outputStream);
        
        restApiClient.posHttptRequest("/rest/api/2/issue/", outputStream.toString());
    }
    
    private void scanRacks() {
        String selectRackedServers="SELECT c FROM Computers c WHERE c.rack.name REGEXP '[23458][0-9][0-9][0-9][0-9]'";
        Query query=entityManager.createQuery(selectRackedServers); List<Computers> listServers=query.getResultList();
    }
    
    @PreDestroy
    private void cleanUp() {
        entityManager.close();
    }
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ru.rambler.irm2;

import java.io.Serializable;
import java.sql.Connection;
import java.util.*;
import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.ejb.Startup;

/**
 *
 * @author a.shalin
 */
@Singleton
@Startup
@LocalBean
public class CentralPoint implements Serializable{
    @Deprecated
    private Connection dbhIrmdb;
    
    private static CentralPoint instance = null;
    
    @Deprecated
    public Connection getDbhIrmdb() {
        return dbhIrmdb;
    }

    public static List parse(String str) {
        List<String> parsed=new ArrayList<>();
//        String[] sourceStr=str.trim().split("\\s+");
        return Arrays.asList(str.trim().split("\\s+"));
//        return sourceStr.split("\\s+");
//        return parsed;
    }

    public static CentralPoint getInstance() {
        if(instance == null) {
            instance = new CentralPoint();
        }
        return instance;
    }

    public CentralPoint() {

    }
}
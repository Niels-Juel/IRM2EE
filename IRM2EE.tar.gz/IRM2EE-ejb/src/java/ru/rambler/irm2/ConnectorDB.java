/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.rambler.irm2;

import ru.rambler.irm2.entries.Replaces;
import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;

/**
 *
 * @author a.shalin
 */
@Stateless
@LocalBean
public class ConnectorDB {
    @PersistenceContext(unitName = "IRM2EE-ejbPU", type=PersistenceContextType.TRANSACTION)
    private EntityManager entityManager;

    public EntityManager getEntityManager() {
        return entityManager;
    }
    
    @PostConstruct
    private void postConstructChores() {
        Replaces replaceEntry=entityManager.find(Replaces.class, 9138);
    }
}

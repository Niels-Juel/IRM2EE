/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.rambler.irm2;

import static com.sun.faces.facelets.util.Path.context;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import org.apache.http.HttpHost;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.ProtocolException;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.DefaultRedirectHandler;
import org.apache.http.impl.client.DefaultRedirectStrategy;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.client.LaxRedirectStrategy;
import org.apache.http.protocol.HttpContext;

/**
 *
 * @author a.shalin
 */
@Stateless
@LocalBean
public class RestApiClient {
    private final String user, password;
    private final HttpHost targetHost;
    private final CloseableHttpClient httpClient;
    private final HttpClientContext context;
    
    @PostConstruct
    public void authorize() {
        try {
            Credentials defaultCreds=new UsernamePasswordCredentials(user, password);

            CredentialsProvider credsProvider=new BasicCredentialsProvider();
            credsProvider.setCredentials(new AuthScope(targetHost.getHostName(), targetHost.getPort()), defaultCreds);

            //Create AutoCash instance
            AuthCache authCache=new BasicAuthCache();
            BasicScheme basicAuth=new BasicScheme();
            authCache.put(targetHost, basicAuth);

            //Add AuthCache to the execution context
            context.setCredentialsProvider(credsProvider);
            context.setAuthCache(authCache);

            HttpGet httpGet=new HttpGet("/rest/api/2/issue/TESTWORK-7");
            CloseableHttpResponse response=httpClient.execute(targetHost, httpGet, context);

            if (response.getStatusLine().getStatusCode()==200) {
                System.out.println("Http code:200");
            } else {
                System.out.println("Http code:"+response.getStatusLine().getStatusCode());
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public RestApiClient() {
        context=HttpClientContext.create();
//        httpClient=HttpClients.createDefault();
        httpClient=HttpClientBuilder.create().setRedirectStrategy(new LaxRedirectStrategy()).build();
//        targetHost=new HttpHost("szent-istvan.rambler.ramblermedia.com", 8090, "http");
        targetHost=new HttpHost("prinz-eugen.rambler.ramblermedia.com", 8090, "http");
        user="a.shalin"; password="AlienHighway1488";
    }

    public String posHttptRequest(String url, String jsonText) throws UnsupportedEncodingException, IOException {
        HttpPut postRequest = new HttpPut();
        postRequest.addHeader("Content-Type", "application/json");
        postRequest.addHeader("Accept", "application/json");
        StringEntity jsonEntry=new StringEntity(jsonText);
        StringBuilder result = new StringBuilder();
        
        postRequest.setEntity(jsonEntry);
        HttpResponse response=httpClient.execute(targetHost, postRequest, context);
        if (response.getStatusLine().getStatusCode() != 200) {
            System.out.println("Failed : HTTP error code : "+response.getStatusLine().getStatusCode());
        } else {
            BufferedReader br = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
            String output;
            while ((output = br.readLine()) != null) {
                result.append(output);
            }
            output=result.toString(); System.out.println(output);
            return output;
        }
        
        return null;
    }
}

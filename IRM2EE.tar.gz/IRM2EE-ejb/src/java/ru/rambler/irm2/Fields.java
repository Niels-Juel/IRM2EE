/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.rambler.irm2;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author a.shalin
 */
@XmlAccessorType(XmlAccessType.FIELD)
public class Fields {
    @XmlElement
    private Project project;
    @XmlElement(name = "issuetype")
    private IssueType issueType;
    @XmlElement
    private String description;
    @XmlElement
    private String summary;
    
    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }
    
    public IssueType getIssueType() {
        return issueType;
    }

    
    public void setIssueType(IssueType issueType) {
        this.issueType = issueType;
    }
    
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public Fields() {
        project=new Project();
        issueType=new IssueType();
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package irm2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import ru.rambler.irm2.AuthorizationTag;

/**
 *
 * @author a.shalin
 */
public class AuthorizationTagTest {
    
    public AuthorizationTagTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
     @Test
    public void authorizeJPA() {
        AuthorizationTag instance=new AuthorizationTag();
        instance.setLogin("shalin");
        instance.setPassword("F9937kl");
        
//        instance.authorizeJPA();
        
        assertTrue(instance.getEntityManager().isOpen());
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.rambler.irm2;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.faces.component.EditableValueHolder;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;
import ru.rambler.irm2.entries.*;

/**
 *
 * @author a.shalin
 */
@Named(value = "purchasesManagement")
@ViewScoped
public class PurchasesManagement implements Serializable {
    @Inject
    private AuthorizationTag authorizationTag;
    private List<Purchases> purchMgmt;
    private EntityManager entityManager;
    private Purchases editedPurchase, blankPurchase;
    private int currentOrderIndex;
    private boolean blank;
    private List<String> statusList;
    private final Map<String, Integer> statusMap;
    private String chosenStatus;

    public List<String> getStatusList() {
        return statusList;
    }

    public void setStatusList(List<String> statusList) {
        this.statusList = statusList;
    }

    public boolean isBlank() {
        return blank;
    }

    public void setBlank(boolean blank) {
        this.blank = blank;
    }

    public List<Purchases> getPurchMgmt() {
        return purchMgmt;
    }

    public Purchases getEditedPurchase() {
        return editedPurchase;
    }

    public void setEditedPurchase(Purchases editedPurchase) {
        this.editedPurchase = editedPurchase;
    }

    public int getCurrentOrderIndex() {
        return currentOrderIndex;
    }

    public void setCurrentOrderIndex(int currentOrderIndex) {
        this.currentOrderIndex = currentOrderIndex;
    }

    public Purchases getBlankPurchase() {
        return blankPurchase;
    }

    public void setBlankPurchase(Purchases blankPurchase) {
        this.blankPurchase = blankPurchase;
    }

    public String getChosenStatus() {
        return chosenStatus;
    }

    public void setChosenStatus(String chosenStatus) {
        this.chosenStatus = chosenStatus;
    }
    
    public void switchAjaxLoading(ValueChangeEvent event) {
//        this.clientRows = (Boolean) event.getNewValue() ? CLIENT_ROWS_IN_AJAX_MODE : 0;
    }
 
    @Transactional(Transactional.TxType.REQUIRED)
    public void remove() {
        entityManager.remove(entityManager.find(Purchases.class, currentOrderIndex));
        refreshPurchList();
    }
 
    @Transactional(Transactional.TxType.REQUIRED)
    public void store() {
        if (blank) {
            blankPurchase.setStatusId(statusMap.get(chosenStatus));
            entityManager.persist(blankPurchase);
            blankPurchase=new Purchases();
            refreshPurchList();
        } else {
            editedPurchase.setStatusId(statusMap.get(chosenStatus));
            entityManager.merge(editedPurchase);
            refreshPurchList();
        }
    }
    
    /**
     * Creates a new instance of PurchasesManagement
     */
    public PurchasesManagement() {
        blankPurchase=new Purchases();
        editedPurchase=blankPurchase;
        
        statusList=new ArrayList<>();
        statusMap=new HashMap<>();
    }
    
    @PostConstruct
    private void postConstructChores() {
        entityManager=authorizationTag.getEntityManager();
        refreshPurchList();
        
        Query query=entityManager.createNamedQuery("PurchaseStatus.findAll");
        List<PurchaseStatus> purchStatList=query.getResultList();
        for (PurchaseStatus ps: purchStatList) {
            statusList.add(ps.getName());
            statusMap.put(ps.getName(), ps.getId());
        }
    }
    
    public void resetValues() {
//        chosenStatus=editedPurchase.getStatus().getName();
        
        FacesContext facesContext = FacesContext.getCurrentInstance();
        
        UIComponent root = facesContext.getViewRoot();

        ((EditableValueHolder) root.findComponent("j_idt21:cost")).resetValue();
        ((EditableValueHolder) root.findComponent("j_idt21:quantity")).resetValue();
        ((EditableValueHolder) root.findComponent("j_idt21:project")).resetValue();
    }
    
    private void refreshPurchList() {
        Query query=entityManager.createNamedQuery("Purchases.findAll");
        purchMgmt=null;
        purchMgmt=query.getResultList();
        
        int index=1;
        for(Purchases purchOrd: purchMgmt) {
            purchOrd.setIndex(index++);
        }
    }
    
    //Scaffolding
    public String getStatusName(int status_id) {
        PurchaseStatus purchStat=entityManager.find(PurchaseStatus.class, status_id);
        
        return purchStat.getName();
    }
}

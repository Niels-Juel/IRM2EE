/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.rambler.irm2.deprecated;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

/**
 *
 * @author a.shalin
 * @deprecated 
 */
@Deprecated
@Entity
@Table(name="photo")
public class UploadedImage implements Serializable {
    private static final long serialVersionUID = -8192553629588066292L;
    
    @Id
    @GeneratedValue
    @Column(name="pid")
    private Integer pid;
    
    private int fileLength;
    
    @Column(name="name")
    private String name;
    
    @Column(name="aid")
    private String aname;
    
    @Lob
    @Column(name="data")
    @Basic(fetch = FetchType.LAZY)
    private byte[] data;

    // getters and setters    
    public byte[] getData() {
        return data;
    }
    
    public void setData(byte[] data) {
        this.data=data;
    }
    
    public String getAname() {
        return aname;
    }
    
    public void setAname(String aname) {
        this.aname=aname;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name=name;
    }
    
    public Integer getPid() {
        return pid;
    }
    
    public void setPid(Integer pid) {
        this.pid=pid;
    }
    
    public int getLength() {
        return fileLength;
    }
    
    public void setLength(int fileLength) {
        this.fileLength=fileLength;
    }
}

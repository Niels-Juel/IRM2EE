/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.rambler.irm2.deprecated;

import java.io.Serializable;

/**
 *
 * @author a.shalin
 * @deprecated 
 */
@Deprecated
public class ComputerParts implements Serializable{
    private String query, store_id, store_serial, part_types_name, 
            parts_name, parts_pn, parts_description, manufacturers_name, category_name;
    
    public String getStore_id() {
        return store_id;
    }
    
    public void setStore_id(String store_id) {
        this.store_id=store_id;
    }
    
    public String getPart_types_name() {
        return part_types_name;
    }
    
    public void setPart_types_name(String part_types_name) {
        this.part_types_name=part_types_name;
    }
    
    public String getParts_name() {
        return parts_name;
    }
    
    public void setParts_name(String parts_name) {
        this.parts_name=parts_name;
    }
    
    public String getParts_pn() {
        return parts_pn;
    }
    
    public void setParts_pn(String parts_pn) {
        this.parts_pn=parts_pn;
    }
    
    public String getParts_description() {
        return parts_description;
    }
    
    public void setParts_description(String parts_description) {
        this.parts_description=parts_description;
    }
    
    public String getManufacturers_name() {
        return manufacturers_name;
    }
    
    public void setManufacturers_name(String manufacturers_name) {
        this.manufacturers_name=manufacturers_name;
    }
    
    public String getCategory_name() {
        return category_name;
    }
    
    public void setCategory_name(String category_name) {
        this.category_name=category_name;
    }
    
    public String getStore_serial() {
        return store_serial;
    }
    
    public void setStore_serial(String store_serial) {
        this.store_serial=store_serial;
    }
    
    public ComputerParts() {
        
    }
}

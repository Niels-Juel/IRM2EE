/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.rambler.irm2.deprecated;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import javax.faces.context.*;
import java.util.*;
import java.sql.*;
import java.io.*;
import java.text.ParseException;

/**
 *
 * @author a.shalin
 */
//@ManagedBean
@Named
@Deprecated
@SessionScoped
public class AdvancedSearchComp implements Serializable{
    private Map<String, String> serverCriteria;
    private String serviceMessages, queryComputersFilter, chosenLocServer, rackUnit, compSerial, partSerialz, ram;
    private boolean isByMask;
    private Connection dbhIrmdb;
    private String[] locServer;
    private List<String> groups;
    private List<String> locations;
    private List<String> chosenGroups;
    private List<String> chosenLocations;
    private Map<String, String> hashGroups;
    private Map<String, String> hashLocs;
    private List<String> listRacks;
    private List<String> chosenRacks;
    private List<String> types;
    private List<String> chosenTypes;
    private List<String> manufacturers;
    private List<String> chosenManufacturers;
    private List<String> parts;
    private List<String> chosenParts;
    private Set<String> uniqComps;
    private List<String> cpuModels;
    private List<String> chosenCpuModels;
    private List<String> moboModels;
    private List<String> chosenMoboModels;
    private List<ComputerInfo> selectedComputers;
    private List<ComputerParts> selectedComputerParts;
    private ComputerInfo currentComp, backupCompEntry;
    private List<Person> contacts;
    private List<String> contactList;
    private List<String> operationSystems;
    private List<String> statusList;
    private List<String> companies;
    private List<String> computerModels;
    private List<String> monServers;
    private final String standardSortOrder, baseFilterServersQuery, basePartsQuery;
    private String sortOrder;
    private boolean isInLease;
    
    public String logApproveChanges(ComputerInfo oldEntry, ComputerInfo newEntry) {
        String logEntry="";
        return logEntry;
    }
    
    public void sortByName() {
        sortOrder=" ORDER BY computers.name;";
        try {
            seekServer();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void sortById() {
        sortOrder=" ORDER BY computers.id;";
        try {
            seekServer();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void sortBySerial() {
        sortOrder=" ORDER BY computers.serial;";
        try {
            seekServer();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void sortByInv() {
        sortOrder=" ORDER BY computers.inv_number;";
        try {
            seekServer();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void sortByGroup() {
        sortOrder=" ORDER BY groups.name;";
        try {
            seekServer();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }    
    
    public void sortByLocation() {
        sortOrder=standardSortOrder;
        try {
            seekServer();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }    
    
    public List<ComputerParts> getSelectedComputerParts(){
        return selectedComputerParts;
    }
    
    public String approveChanges() throws SQLException, ParseException {
        String rack_id=currentComp.getRack_id();
        if (!currentComp.getRacks_name().isEmpty()) {
            String queryService="SELECT * FROM racks WHERE name='"+currentComp.getRacks_name()+"' LIMIT 1";
            Statement sth=dbhIrmdb.createStatement();
            ResultSet rowSet=sth.executeQuery(queryService);
            while (rowSet.next()) {
                rack_id=rowSet.getString("id");
            }
            sth.close();
            rowSet.close();
        }   

        String group_id=currentComp.getGroups_id();
        if (!currentComp.getRacks_name().isEmpty()) {
            String queryService="SELECT * FROM groups WHERE name='"+currentComp.getGroups_name()+"' LIMIT 1";
            Statement sth=dbhIrmdb.createStatement();
            ResultSet rowSet=sth.executeQuery(queryService);
            while (rowSet.next()) {
                group_id=rowSet.getString("id");
            }
            sth.close();
            rowSet.close();
        }        
        
        String status_id=currentComp.getComputers_status_id();
        if (!currentComp.getComputers_status_name().isEmpty()) {
            String queryService="SELECT * FROM computer_status WHERE name='"+currentComp.getComputers_status_name()+"' LIMIT 1";
            Statement sth=dbhIrmdb.createStatement();
            ResultSet rowSet=sth.executeQuery(queryService);
            while (rowSet.next()) {
                status_id=rowSet.getString("id");
            }
            sth.close();
            rowSet.close();
        }   
        
        String vendor_id=currentComp.getVendor_id();
        if (!currentComp.getVendor_name().isEmpty()) {
            String queryService="SELECT * FROM companies WHERE name='"+currentComp.getVendor_name()+"' LIMIT 1";
            Statement sth=dbhIrmdb.createStatement();
            ResultSet rowSet=sth.executeQuery(queryService);
            while (rowSet.next()) {
                vendor_id=rowSet.getString("id");
            }
            sth.close();
            rowSet.close();
        }
        
        String models_id=currentComp.getModels_id();
        if (!currentComp.getVendor_name().isEmpty()) {
            String queryService="SELECT * FROM models WHERE name='"+currentComp.getModels_name()+"' LIMIT 1";
            Statement sth=dbhIrmdb.createStatement();
            ResultSet rowSet=sth.executeQuery(queryService);
            while (rowSet.next()) {
                models_id=rowSet.getString("id");
            }
            sth.close();
            rowSet.close();
        }
        
        String contacts_id=currentComp.getContacts_id();
        if (!currentComp.getDisplayName().isEmpty()) {
            String[] names=currentComp.getDisplayName().split("\\s+");
            String queryService="SELECT * FROM contacts WHERE name='"+names[0]+"' AND firstname='"+names[1]+"' LIMIT 1";
            System.out.println(queryService);
            Statement sth=dbhIrmdb.createStatement();
            ResultSet rowSet=sth.executeQuery(queryService);
            while (rowSet.next()) {
                contacts_id=rowSet.getString("id");
            }
            sth.close();
            rowSet.close();
            currentComp.changeContact();
        }

        PreparedStatement commonUpdate=null;
        try {
            String queryUpdate="UPDATE computers SET name=?, serial=?, inv_number=?, comments=?, rack_unit=?, box_unit=?, ram=?,"
                    + "rack_id=?, group_id=?, cpu=?, os=?, osver=?, mb_manufact=?, mb_type=?, status_id=?, vendor_id=?, model_id=?, "
                    + "contact_id=?, buy_date=?, lease_expired=?, guarantee=?, mon_server=?, mon_fqdn=? WHERE ID="
                    +currentComp.getComputers_id()+";";
            dbhIrmdb.setAutoCommit(false);
            /* name=1, serial=2, inv_number=3, comments=4, rack_unit=5, box_unit=6, ram=7, rack_id=8, group_id=9, cpu=10,
             * os=11, osver=12, mb_manufact=13, mb_type=14, status_id=15, vendor_id=16, models_id=17, contact_id=18,
             * buy_date=19, lease_expired=20, guarantee=21, mon_server=22, mon_fqdn=23
             */
            commonUpdate=dbhIrmdb.prepareStatement(queryUpdate);
            updateStringField(commonUpdate, 1, currentComp.getComputers_name());
            updateStringField(commonUpdate, 2, currentComp.getComputers_serial());
            updateStringField(commonUpdate, 3, currentComp.getComputers_inv_number());
            updateStringField(commonUpdate, 4, currentComp.getComments());
            commonUpdate.setInt(5, Integer.parseInt(nullify(currentComp.getComputers_rack_unit())));
            commonUpdate.setInt(6, Integer.parseInt(nullify(currentComp.getBox_unit())));
            updateStringField(commonUpdate, 7, currentComp.getRam());
            commonUpdate.setInt(8, Integer.parseInt(nullify(rack_id)));
            commonUpdate.setInt(9, Integer.parseInt(nullify(group_id)));
            updateStringField(commonUpdate, 10, currentComp.getCpu());
            if (currentComp.getOsFullDesc().equals("null\\null")) {
                commonUpdate.setNull(11, java.sql.Types.VARCHAR);
                commonUpdate.setNull(12, java.sql.Types.VARCHAR);
            } else {
                String[] os=currentComp.getOsFullDesc().split("\\\\");
                commonUpdate.setString(11, os[0]);
                commonUpdate.setString(12, os[1]);
            }
            if (currentComp.getMbFullDesc().equals("null\\null")) {
                commonUpdate.setNull(13, java.sql.Types.VARCHAR);
                commonUpdate.setNull(14, java.sql.Types.VARCHAR);
            } else {
                String[] mb=currentComp.getMbFullDesc().split("\\\\");
                commonUpdate.setString(13, mb[0]);
                commonUpdate.setString(14, mb[1]);
            }
            updateIntField(commonUpdate, 15, status_id);
            updateIntField(commonUpdate, 16, vendor_id);
            updateIntField(commonUpdate, 17, models_id);
            updateIntField(commonUpdate, 18, contacts_id);
            updateDateField(commonUpdate, 19, currentComp.getBuy_date());
            updateDateField(commonUpdate, 20, currentComp.getLease_expired());
            updateDateField(commonUpdate, 21, currentComp.getGuarantee());
            updateStringField(commonUpdate, 22, currentComp.getMon_server());
            updateStringField(commonUpdate, 23, currentComp.getMon_fqdn());
            commonUpdate.executeUpdate();
            dbhIrmdb.commit();
            System.out.println("Database updated");
        } catch (SQLException ex) {
            serviceMessages=ex.getStackTrace().toString();
            try {
                System.err.print("Transaction is being rolled back");
                dbhIrmdb.rollback();
                ex.printStackTrace();
            } catch(SQLException excep) {
                excep.printStackTrace();
            } 
        } 
        finally {
            if (commonUpdate != null) {
                commonUpdate.close();
            }
            dbhIrmdb.setAutoCommit(true);
        }
        return "compDetails.xhtml";
    }

    public void updateStringField(PreparedStatement commonUpdate, int index, String value) throws SQLException{
        if(value.isEmpty()) {
            commonUpdate.setNull(index, java.sql.Types.VARCHAR);
        } else {
            commonUpdate.setString(index, value);
        }
    }
    
    public void updateDateField(PreparedStatement commonUpdate, int index, java.util.Date value) throws SQLException{
        if(value==null) {
            commonUpdate.setNull(index, java.sql.Types.DATE);
        } else {
            commonUpdate.setDate(index, new java.sql.Date(value.getTime()));
        }
    }
    
    public void updateIntField(PreparedStatement commonUpdate, int index, String value) throws SQLException{
        if(nullify(value).equals("0")) {
            commonUpdate.setNull(index, java.sql.Types.INTEGER);
        } else {
            commonUpdate.setInt(index, Integer.parseInt(nullify(value)));
        }
    }
    
    public String viewCompDetails() throws SQLException, CloneNotSupportedException{
        acquireCurrentComp();
        return "compDetails.xhtml";
    }
    
    public void download() throws IOException {
        if(!selectedComputers.isEmpty()) {
            FacesContext fc = FacesContext.getCurrentInstance();
            ExternalContext ec = fc.getExternalContext();
            String contentType="application/octet-stream";
            String fileName="selected_computers.csv";
            String content=convertCSV();
            byte[] bytes = content.getBytes();
            int contentLength = bytes.length; 

            ec.responseReset(); // Some JSF component library or some Filter might have set some headers in the buffer beforehand. We want to get rid of them, else it may collide.
            ec.setResponseContentType(contentType); // Check http://www.iana.org/assignments/media-types for all types. Use if necessary ExternalContext#getMimeType() for auto-detection based on filename.
            ec.setResponseContentLength(contentLength); // Set it with the file size. This header is optional. It will work if it's omitted, but the download progress will be unknown.
            ec.setResponseHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\""); // The Save As popup magic is done here. You can give it any file name you want, this only won't work in MSIE, it will use current request URL as file name instead.

            OutputStream output = ec.getResponseOutputStream();
            output.write(bytes, 0, contentLength);

            fc.responseComplete(); // Important! Otherwise JSF will attempt to render the response which obviously will fail since it's already written with a file and closed.
        }
    }
    
    public void acquireCurrentComp() throws SQLException, CloneNotSupportedException {
        FacesContext facesContext=FacesContext.getCurrentInstance();
        String passedIndex=(String) facesContext.getExternalContext().getRequestParameterMap().get("index");
        int index=Integer.parseInt(passedIndex);

        currentComp=selectedComputers.get(index);
        String queryMacs="SELECT * FROM irmdb.networking_ports WHERE device_on="+currentComp.getComputers_id();
        this.serviceMessages+="\n"+queryMacs;
        Statement sth=dbhIrmdb.createStatement();
        ResultSet rowSet=sth.executeQuery(queryMacs);
        while (rowSet.next()) {
            currentComp.putMac(rowSet.getString("ifmac"));
        }
        rowSet.close();
  
        ComputerParts storeItem;
        selectedComputerParts.clear();
        
        String queryParts="SELECT \n" +
            "    store.id AS store_id,\n" +
            "    store.serial AS store_serial,\n" +
            "    part_types.name AS part_types_name,\n" +
            "    parts.name AS parts_name,\n" +
            "    parts.pn AS parts_pn,\n" +
            "    parts.description AS parts_description,\n" +
            "    manufacturers.name AS manufacturers_name,\n" +
            "    category.name AS category_name\n" +
            "FROM\n" +
            "    store\n" +
            "        LEFT JOIN\n" +
            "    parts ON part_id = parts.id\n" +
            "        LEFT JOIN\n" +
            "    part_types ON parts.type_id = part_types.id\n" +
            "        LEFT JOIN\n" +
            "    manufacturers ON parts.manufacturer_id = manufacturers.id\n" +
            "        LEFT JOIN\n" +
            "    category ON category_id = category.id\n" +
            "WHERE\n" +
            "    computer_id="+currentComp.getComputers_id();
        
        String queryScannedDocuments="SELECT \n" +
            "    *\n" +
            "FROM\n" +
            "    irmdb.scans_relation\n" +
            "        LEFT JOIN\n" +
            "    scans ON scan_id = scans.id\n" +
            "WHERE\n" +
            "    comp_id ="+currentComp.getComputers_id();
        
        rowSet=sth.executeQuery(queryParts);
        while (rowSet.next()) {
            storeItem=new ComputerParts();
            storeItem.setStore_id(rowSet.getString("store_id"));
            storeItem.setPart_types_name(rowSet.getString("part_types_name"));
            storeItem.setParts_name(rowSet.getString("parts_name"));
            storeItem.setParts_pn(rowSet.getString("parts_pn"));
            storeItem.setManufacturers_name(rowSet.getString("manufacturers_name"));
            storeItem.setCategory_name(rowSet.getString("category_name"));
            storeItem.setStore_serial(rowSet.getString("store_serial"));
            storeItem.setParts_description(rowSet.getString("parts_description"));
            selectedComputerParts.add(storeItem);
        }
//        rowSet=sth.executeQuery(queryScannedDocuments);
//        currentComp.clearScannedList();
//        while (rowSet.next()) {
//            ScannedDocument scan=new ScannedDocument();
//            scan.setFilename(rowSet.getString("filename"));
//            currentComp.addScannedDocument(scan);
//        }
        sth.close();
        
        backupCompEntry=currentComp.clone();
    }
    
    public boolean getIsInLease() {
        return isInLease;
    }
    
    public void setIsInLease(boolean isInLease) {
        this.isInLease=isInLease;
    }
    
    public ComputerInfo getCurrentComp() {
        return currentComp;
    }
    
    public ComputerInfo getBackupCompEntry() {
        return backupCompEntry;
    }
    
    public List<ComputerInfo> getSelectedComputers() {
        return selectedComputers;
    }
    
    public List<String> getOperationSystems() {
        return operationSystems;
    }
    
    public List<Person> getContacts() {
        return contacts;
    }
    
    public List<String> getContactList() {
        return contactList;
    }
    
    public void setNameServer(String nameServer) {
        this.serverCriteria.put("name", cauterize(nameServer));
    }
    
    public String getNameServer() {
        return this.serverCriteria.get("name");
    }
    
    public void setSerialServer(String serialServer) {
        this.compSerial=cauterize(serialServer);
        if (!serialServer.equals("")) serverCriteria.put("serial", cauterize(serialServer)); //uniqComps.add(serialServer);
    }
    
    public String getSerialServer() {
        return this.compSerial;
    }
    
    public void setInvServer(String invServer) {
        this.serverCriteria.put("inv_number", cauterize(invServer));
    }
    
    public String getInvServer() {
        return this.serverCriteria.get("inv_number");
    }
    
    public void setRam(String ram) {
        this.ram=cauterize(ram);
    }
    
    public String getRam() {
        return this.ram;
    }
    
    public void setServiceMessages(String serviceMessages) {
        this.serviceMessages=serviceMessages;
    }
    
    public String getServiceMessages() {
        return this.serviceMessages;
    }
    
    public String getChosenLocServer() {
        return this.chosenLocServer;
    }
    
    public void setChosenLocServer(String chosenLocServer) {
        this.chosenLocServer=chosenLocServer;
    }
    
    public List<String> getManufacturers() {
        return this.manufacturers;
    }   
    
    public List<String> getChosenManufacturers() {
        return this.chosenManufacturers;
    }

    public void setChosenManufacturers(List chosenManufacturers) {
        this.chosenManufacturers=chosenManufacturers;
    }    
    
    public List<String> getGroups() {
        return this.groups;
    }
    
    public List<String> getParts() {
        return this.parts;
    }
    
    public List<String> getMonServers() {
        return this.monServers;
    }
    
    public void filterRacks() throws SQLException {
        if (!chosenLocations.isEmpty()) {
            String queryRacks="SELECT * FROM racks WHERE";
            String subClause=" "; boolean isComplex=false;            
            for(String loc: chosenLocations) {
                if(isComplex) {
                    subClause=subClause+" OR ";
                }
                subClause=subClause+"location_id="+this.hashLocs.get(loc);
                isComplex=true;
            }        
            subClause=subClause+";";
            queryRacks=queryRacks+subClause;

            listRacks.clear();
            Statement sth=dbhIrmdb.createStatement();
            ResultSet rowSet=sth.executeQuery(queryRacks);
            while (rowSet.next()) {
                listRacks.add(rowSet.getString(2));
            }
            sth.close();
            Collections.sort(listRacks);
        }
    }

    public void filterManufacturers() throws SQLException{
        if (!chosenTypes.isEmpty()) {
            manufacturers.clear(); manufacturers.add(0,""); int i=0;
            uniqComps.clear();
            parts.clear(); parts.add(0, "");
            HashSet<String> uniqManuf;
            uniqManuf=new HashSet<>();
            for (int j=0; j<chosenTypes.size(); j++) {
                String queryManuf="SELECT parts.id, manufacturers.id, part_types.id, manufacturers.name, part_types.name " +
                    "FROM irmdb.parts LEFT JOIN manufacturers ON manufacturer_id = manufacturers.id LEFT JOIN " +
                    "part_types ON type_id = part_types.id WHERE part_types.name = '"+chosenTypes.get(j)+"';";
                Statement sth=dbhIrmdb.createStatement();
                ResultSet rowSet=sth.executeQuery(queryManuf);
                String name;
                while (rowSet.next()) {
                    name=rowSet.getString(4);
                    uniqManuf.add(name);
                }                
                sth.close();
                for (String vendor: uniqManuf) {
                    manufacturers.add(vendor);
                }          
                Collections.sort(manufacturers);
            }    
        }
    }
    
    public void filterParts() throws SQLException {
        if (!chosenManufacturers.isEmpty()) {
            String queryParts;
            HashSet<String> uniqParts=new HashSet<>();
            parts.clear(); parts.add(0, ""); //int i=0;
            uniqComps.clear();
            for (String itType: chosenTypes) {
                for (String itManuf: chosenManufacturers) {
                    queryParts=basePartsQuery+itType+"' AND manufacturers.name='"+itManuf+"'";
                    Statement sth=dbhIrmdb.createStatement();
                    ResultSet rowSet=sth.executeQuery(queryParts);
                    while (rowSet.next()) {
                        uniqParts.add(rowSet.getString(2));
                    }                
                    sth.close();
                }
            }
            for (String part:uniqParts) {
                parts.add(part);
            }
            Collections.sort(parts);
        }
    }
    
    public List<String> getLocations() {
        return this.locations;
    }
    
    public void setChosenLocations(List<String> chosenLocations) {
        this.chosenLocations=chosenLocations;
    }
    
    public List<String> getChosenLocations() {
        return this.chosenLocations;
    }
    
    public void setChosenGroups(List<String> chosenGroups) {
        this.chosenGroups=chosenGroups;
    }
    
    public List<String> getChosenGroups() {
        return this.chosenGroups;
    }
    
    public List<String> getListRacks() throws SQLException {
        return this.listRacks;
    }
    
    public List<String> getChosenRacks() {
        return this.chosenRacks;
    }
    
    public void setChosenRacks(List<String> racks) {
        this.chosenRacks=racks;
    }
    
    public List<String> getChosenTypes() {
        return this.chosenTypes;
    }
    
    public void setChosenTypes(List<String> chosenTypes) {
        this.chosenTypes=chosenTypes;
    }    
    
    public List<String> getChosenParts() {
        return this.chosenParts;
    }
    
    public void setChosenParts(List<String> chosenParts) {
        this.chosenParts=chosenParts;
    }    
    
    public void setRackUnit(String rackUnit) {
        this.rackUnit=rackUnit;
    }
    
    public String getRackUnit() {
        return this.rackUnit;
    }
    
    public List<String> getTypes() {
        return this.types;
    }
    
    public String getPartSerialz() {
        return this.partSerialz;
    }
    
    public void setPartSerialz(String partSerialz) {
        this.partSerialz=cauterize(partSerialz);
    }
    
    public List<String> getCpuModels() {
        return this.cpuModels;
    }

    public List<String> getChosenCpuModels() {
        return this.chosenCpuModels;
    }
    
    public void setChosenCpuModels(List<String> chosenCpuModels) {
        this.chosenCpuModels=chosenCpuModels;
    }    
    
    public List<String> getChosenMoboModels() {
        return this.chosenMoboModels;
    }
    
    public void setChosenMoboModels(List<String> chosenMoboModels) {
        this.chosenMoboModels=chosenMoboModels;
    }    
    
    public List<String> getMoboModels() {
        return this.moboModels;
    }
    
    public List<String> getStatusList() {
        return this.statusList;
    }
    
    public List<String> getCompanies(){
        return companies;
    }
    
    public List<String> getComputerModels(){
        return computerModels;
    }
    
    public void seekServer() throws SQLException{
        java.util.Date today = new java.util.Date();
        java.sql.Date sqlToday = new java.sql.Date(today.getTime());
        
        String subClause; boolean isComplex=false;
        
        if (!chosenParts.isEmpty()) {
            String queryParts="SELECT \n" +
                "    store.id,store.part_id,store.serial,store.computer_id\n" +
                "FROM\n" +
                "    store\n" +
                "        LEFT JOIN\n" +
                "    parts ON part_id = parts.id\n" +
                "WHERE computer_id IS NOT NULL";
            subClause=""; uniqComps.add("0");
            for (String part: chosenParts) {
                if (isComplex) subClause+=" OR ";
                subClause+="parts.name='"+part+"'";
                isComplex=true;
            }
            if (isComplex) subClause="("+subClause+")";
            queryParts+=" AND "+subClause;
            
            Statement sth=dbhIrmdb.createStatement();
            ResultSet rowSet=sth.executeQuery(queryParts);
            while (rowSet.next()) {
                uniqComps.add(rowSet.getString(1));
            }         
            sth.close();
        }
        
        String[] partSerial=parse(partSerialz);
        if (partSerial.length!=0) {
            String queryParts="SELECT id, computer_id FROM store WHERE computer_id IS NOT NULL AND ("; isComplex=false;
            for (int i=0; i<partSerial.length; i++) {
                if (isComplex) queryParts+=" OR ";
                queryParts+="serial='"+partSerial[i]+"'";
                isComplex=true;
            }
            
            queryParts+=")";
            
            Statement sth=dbhIrmdb.createStatement();
            ResultSet rowSet=sth.executeQuery(queryParts);
            while (rowSet.next()) {
                uniqComps.add(rowSet.getString(2));
            }         
            sth.close();
        }        
        
        queryComputersFilter=baseFilterServersQuery;
        
        if (!ram.isEmpty()) {
            queryComputersFilter+=" AND computers.ram>="+ram;
        }
        
        if (!uniqComps.isEmpty()) {
            isComplex=false; subClause="";
            for (String serial: uniqComps) {
                if (isComplex) subClause+=" OR ";
                subClause+="computers.id='"+serial+"'";
                isComplex=true;
            }
            if (isComplex) subClause="("+subClause+")";
            queryComputersFilter+=" AND "+subClause;
        }

        Iterator it = serverCriteria.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pairs = (Map.Entry)it.next();
            if (!pairs.getValue().equals("")) {
                isComplex=false;
                queryComputersFilter+=" AND ";
                String subquery="";
                String key=(String) pairs.getKey();
                String[] values=parse((String) pairs.getValue());
                for (String value: values) {
                    if (isComplex) subquery+=" OR ";
                    subquery+=("computers."+key+" LIKE '"+value+"'");
                    isComplex=true;
                }
                queryComputersFilter+=("("+subquery+")");
            }
        }
        
        if (!chosenGroups.isEmpty()) {
            subClause="("; isComplex=false; boolean isNull=false;
            for(String group: chosenGroups) {
                if (group.equals("null")) isNull=true;
                if(isComplex) {
                    subClause=subClause+" OR ";
                }
                if (this.hashGroups.get(group)==null) isNull=true;
                subClause=subClause+"group_id="+this.hashGroups.get(group);
                isComplex=true;
            }        
            subClause=subClause+")";
            if (!isNull) queryComputersFilter=queryComputersFilter+" AND "+subClause;
        }
        
        if (!chosenCpuModels.isEmpty()) {
            subClause="("; isComplex=false; 
            for(String cpu: chosenCpuModels) {
                if(isComplex) {
                    subClause=subClause+" OR ";
                }
                if(cpu.equals(" NULL ")) {
                    subClause=subClause+"cpu IS NULL";
                }
                else subClause=subClause+"cpu='"+cpu+"'";
                isComplex=true;
            }        
            subClause+=")";
            queryComputersFilter+=" AND "+subClause;
        }
        
        if (!chosenMoboModels.isEmpty()) {
            subClause="("; isComplex=false; 
            for(String mobo: chosenMoboModels) {
                String[] mb=mobo.split("\\\\");
                if(isComplex) {
                    subClause=subClause+" OR ";
                }
                subClause=subClause+"(mb_manufact='"+mb[0]+"' AND mb_type='"+mb[1]+"')";
                isComplex=true;
            }        
            subClause+=")";
            queryComputersFilter+=" AND "+subClause;
        }        
        
        if (!chosenLocations.isEmpty()) {
            subClause=""; boolean isNull=false;
            int complexity=0;
            for(String loc: chosenLocations) {
                if (loc.equals("null")) isNull=true;
                if(complexity>0) {
                    subClause=subClause+" OR ";
                }
                if (this.hashLocs.get(loc)==null) isNull=true;
                subClause=subClause+"racks.location_id="+this.hashLocs.get(loc);
                complexity++;
            }        
            if (complexity>1) subClause="("+subClause+")";
            if (!isNull) queryComputersFilter=queryComputersFilter+" AND "+subClause;
        }
        
        if (!chosenRacks.isEmpty()) {
            subClause=""; isComplex=false; boolean isNull=false;
            for(String rack: chosenRacks) {
                if (rack.equals("")) isNull=true;
                if(isComplex) {
                    subClause=subClause+" OR ";
                }
                subClause=subClause+"racks.name='"+rack+"'";
                isComplex=true;
            }        
            if (isComplex) 
                subClause="("+subClause+")";
            if (!isNull) queryComputersFilter=queryComputersFilter+" AND "+subClause;
        }
        
        if(isInLease) {
            subClause="lease_expired IS NOT NULL";
            queryComputersFilter+=(" AND "+subClause);
        }
        
        queryComputersFilter=queryComputersFilter+sortOrder;
        
        serviceMessages=queryComputersFilter;
        
        ComputerInfo computer;
        selectedComputers.clear();

        int index=0;
        dbhIrmdb.setAutoCommit(false);
        PreparedStatement preparedSelect;
        preparedSelect=dbhIrmdb.prepareStatement(queryComputersFilter);
        ResultSet rowSet=preparedSelect.executeQuery();
        dbhIrmdb.commit();
        while (rowSet.next()) {
            computer=new ComputerInfo();
            computer.setIndex(index); index++;
            computer.setComputers_id(rowSet.getString("computers_id"));
            computer.setComputers_name(rowSet.getString("computers_name"));
            computer.setLocations_name(rowSet.getString("locations_name"));
            computer.setRack_id(rowSet.getString("rack_id"));
            computer.setRacks_name(rowSet.getString("racks_name"));
            computer.setComputers_rack_unit(rowSet.getString("computers_rack_unit"));
            computer.setComputers_serial(rowSet.getString("computers_serial"));
            computer.setComputers_inv_number(rowSet.getString("computers_inv_number"));
            computer.setComputers_status_id(rowSet.getString("computers_status_id"));
            computer.setComputers_status_name(rowSet.getString("computers_status_name"));
            computer.setGroups_id(rowSet.getString("group_id"));
            computer.setGroups_name(rowSet.getString("groups_name"));
            computer.setModels_id(rowSet.getString("models_id"));
            computer.setModels_name(rowSet.getString("models_name"));
            computer.setVendor_id(rowSet.getString("vendor_id"));
            computer.setVendor_name(rowSet.getString("vendor_name"));
            computer.setCpu(rowSet.getString("cpu"));
            computer.setRam(rowSet.getString("ram"));
            computer.setOs(rowSet.getString("os"));
            computer.setOsver(rowSet.getString("osver"));
            computer.setOsFullDesc(computer.getOs()+"\\"+computer.getOsver());
            computer.setMb_manufact(rowSet.getString("mb_manufact"));
            computer.setMb_type(rowSet.getString("mb_type"));
            computer.setMbFullDesc(computer.getMb_manufact()+"\\"+computer.getMb_type());
            computer.setComments(rowSet.getString("comments"));
            computer.setBox_unit(rowSet.getString("box_unit"));
            computer.setContacts_id(rowSet.getString("contacts_id"));
            computer.setContacts_name(rowSet.getString("contacts_name"));
            computer.setContacts_firstname(rowSet.getString("contacts_firstname"));
            computer.setDisplayName(computer.getContacts_name()+" "+computer.getContacts_firstname());
            computer.setContacts_email(rowSet.getString("contacts_email"));
            computer.setContacts_mobilephone(rowSet.getString("contacts_mobilephone"));
            computer.setGuarantee(rowSet.getDate("guarantee"));
            computer.setLease_expired(rowSet.getDate("lease_expired"));
            computer.setBuy_date(rowSet.getDate("buy_date"));
            computer.setMon_server(rowSet.getString("mon_server"));
            computer.setMon_fqdn(rowSet.getString("mon_fqdn"));
            if(computer.getLease_expired()!=null) {
                if(rowSet.getDate("lease_expired").compareTo(sqlToday)<0){
                    computer.setIsInLease("Expired");
                } else {
                    computer.setIsInLease(computer.getLease_expired().toString());
                }
            } else {
                computer.setIsInLease("N/A");
            }
            selectedComputers.add(computer);
        }         
        rowSet.close();
        preparedSelect.close();
        
        dbhIrmdb.setAutoCommit(true);
    }
    
    public void clearUiComponents() {
        selectedComputers.clear();
        queryComputersFilter=null;
        isByMask=false;
        serviceMessages="";
        rackUnit="";
        serverCriteria.clear();
        serverCriteria.put("name", "");
        serverCriteria.put("serial", "");
        serverCriteria.put("inv_number", "");
        uniqComps.clear();
        chosenManufacturers.clear();
        manufacturers.clear();
        chosenParts.clear();
        parts.clear();
        chosenTypes.clear();
        compSerial="";
        ram="";
        listRacks.clear();
        chosenRacks.clear();
        chosenLocations.clear();
        chosenGroups.clear();
        chosenCpuModels.clear();
        chosenMoboModels.clear();
        uniqComps.clear();
        sortOrder=standardSortOrder;
    }
    
    private String[] parse(String str) {
        String sourceStr=str.trim();
        return sourceStr.split("\\s+");
    }
    
    public static String cauterize(String rawStr) {
        return rawStr.replaceAll(";", " ");
    }
    
    public AdvancedSearchComp() {
        groups=new ArrayList();
        locations=new ArrayList();
        chosenGroups=new ArrayList<>();
        chosenLocations=new ArrayList<>();
        hashGroups=new HashMap<>();
        hashLocs=new HashMap<>();
        listRacks=new ArrayList();
        chosenRacks=new ArrayList();
        types=new ArrayList();
        chosenTypes=new ArrayList();
        manufacturers=new ArrayList();    
        chosenManufacturers=new ArrayList();
        parts=new ArrayList();
        chosenParts=new ArrayList();
        uniqComps=new HashSet<>();
        cpuModels=new ArrayList<>();
        chosenCpuModels=new ArrayList<>();
        moboModels=new ArrayList<>();
        chosenMoboModels=new ArrayList<>();
        selectedComputers=new ArrayList<>();
        selectedComputerParts=new ArrayList<>();
        contacts=new ArrayList<>();
        contactList=new ArrayList<>();
        operationSystems=new ArrayList<>();
        statusList=new ArrayList<>();
        companies=new ArrayList<>();
        computerModels=new ArrayList<>();
        monServers=new ArrayList<>();
        isByMask=false;
        serverCriteria  = new HashMap<>();
        serverCriteria.put("name", "");
        serverCriteria.put("serial", "");
        serverCriteria.put("inv_number", "");
        rackUnit="";
        standardSortOrder=" ORDER BY locations.name, racks.name, computers.rack_unit;";
        sortOrder=standardSortOrder;
        baseFilterServersQuery="SELECT \n" +
            "    computers.id AS computers_id,\n" +
            "    computers.name AS computers_name,\n" +
            "    locations.name AS locations_name,\n" +
            "    racks.name AS racks_name,\n" +
            "    computers.rack_unit AS computers_rack_unit,\n" +
            "    computers.serial AS computers_serial,\n" +
            "    computers.inv_number AS computers_inv_number,\n" +
            "    computer_status.id AS computers_status_id,\n" +
            "    computer_status.name AS computers_status_name,\n" +
            "    groups.name AS groups_name,\n" +
            "    models.id AS models_id,\n" +
            "    models.name AS models_name,\n" +
            "    companies.id AS vendor_id,\n" +
            "    companies.name AS vendor_name,\n" +
            "    contacts.id AS contacts_id,\n" +
            "    contacts.name AS contacts_name,\n" +
            "    contacts.firstname AS contacts_firstname,\n" +
            "    contacts.email AS contacts_email,\n" +
            "    contacts.mobilephone AS contacts_mobilephone,\n" +
            "    rack_id, group_id, ram, cpu, os, osver, mb_manufact, mb_type, \n" +
            "    comments, box_unit, guarantee, lease_expired, buy_date,\n" +
            "    mon_fqdn, mon_server\n" +
            "FROM\n" +
            "    computers\n" +
            "        LEFT JOIN\n" +
            "    racks ON rack_id = racks.id\n" +
            "        LEFT JOIN\n" +
            "    locations ON racks.location_id = locations.id\n" +
            "        LEFT JOIN\n" +
            "    computer_status ON computers.status_id = computer_status.id\n" +
            "        LEFT JOIN\n" +
            "    groups ON computers.group_id = groups.id\n" +
            "        LEFT JOIN\n" +
            "    contacts ON computers.contact_id = contacts.id\n" +
            "        LEFT JOIN\n" +
            "    models ON computers.model_id = models.id\n" +
            "        LEFT JOIN\n" +
            "    companies ON computers.vendor_id = companies.id\n" +
            "WHERE\n" +
            "    computers.devtype_id = 1";
        
        basePartsQuery="SELECT \n" +
            "    parts.id, parts.name, manufacturers.id, part_types.id, manufacturers.name, part_types.name\n" +
            "FROM\n" +
            "    irmdb.parts\n" +
            "        LEFT JOIN\n" +
            "    manufacturers ON manufacturer_id = manufacturers.id\n" +
            "        LEFT JOIN\n" +
            "    part_types ON type_id = part_types.id\n" +
            "WHERE\n" +
            "    part_types.name = '";
        
        try {
            connectToDB();
        }
        catch (Exception ex) {
            serviceMessages=serviceMessages+"\n"+ex.toString();
        }
    }
    
    private void connectToDB() throws SQLException, ClassNotFoundException{
//        dbhIrmdb=AuthorizationTag.dbhIrmdb;

        String queryCaching="SELECT * FROM groups ORDER BY name";
        Statement sth=dbhIrmdb.createStatement();
        ResultSet rowSet=sth.executeQuery(queryCaching);
        String id, name;
        while (rowSet.next()) {
            id=rowSet.getString(1); name=rowSet.getString(2);
            hashGroups.put(name, id); 
            groups.add(name);
        }
//        Collections.sort(groups);

        queryCaching="SELECT * FROM locations;";
        rowSet=sth.executeQuery(queryCaching);
        while (rowSet.next()) {
            id=rowSet.getString(1); name=rowSet.getString(2);
            hashLocs.put(name, id); 
            locations.add(name);
        }
        Collections.sort(locations);
        
        queryCaching="SELECT * FROM part_types";
        rowSet=sth.executeQuery(queryCaching);
        while (rowSet.next()) {
            name=rowSet.getString(2);
            types.add(name);
        }        
        Collections.sort(types);
        
        queryCaching="SELECT * FROM computer_status";
        rowSet=sth.executeQuery(queryCaching);
        while (rowSet.next()) {
            name=rowSet.getString("name");
            statusList.add(name);
        } 
        
        Set<String> serviceSet=new HashSet<>();
        
        queryCaching="SELECT ID, cpu FROM computers WHERE cpu IS NOT NULL";
        rowSet=sth.executeQuery(queryCaching);
        while (rowSet.next()) {
            name=rowSet.getString(2);
            serviceSet.add(name);
        }
        for(String cpu: serviceSet) {
            cpuModels.add(cpu);
        }
        cpuModels.add("");
        cpuModels.add(" NULL ");
        Collections.sort(cpuModels);
        
        serviceSet.clear();
        queryCaching="SELECT ID, mb_manufact, mb_type FROM computers WHERE mb_type IS NOT NULL";
        rowSet=sth.executeQuery(queryCaching);
        while (rowSet.next()) {
            String manufacturer=rowSet.getString(2);
            String model=rowSet.getString(3);
            serviceSet.add(manufacturer+"\\"+model);
        }
        for(String mobo: serviceSet) {
            moboModels.add(mobo);
        }
        moboModels.add("null\\null");
        Collections.sort(moboModels);
        
        serviceSet.clear();
        queryCaching="SELECT os, osver FROM irmdb.computers WHERE os IS NOT NULL";
        rowSet=sth.executeQuery(queryCaching);
        while (rowSet.next()) {
            String os=rowSet.getString("os");
            String osver=rowSet.getString("osver");
            serviceSet.add(os+"\\"+osver);
        }
        for(String opsys: serviceSet) {
            operationSystems.add(opsys);
        }
        operationSystems.add("null\\null");
        Collections.sort(operationSystems);
        
        queryCaching="SELECT name FROM companies ORDER BY name";
        rowSet=sth.executeQuery(queryCaching);
        while (rowSet.next()) {
            String companyName=rowSet.getString("name");
            companies.add(companyName);
        }
        //Collections.sort(companies);
        //companies.add("null");
        
        queryCaching="SELECT * FROM models ORDER BY name";
        rowSet=sth.executeQuery(queryCaching);
        while (rowSet.next()) {
            String modelName=rowSet.getString("name");
            computerModels.add(modelName);
        }
        
        queryCaching="SELECT * FROM contacts";
        Person contact;
        sth=dbhIrmdb.createStatement();
        rowSet=sth.executeQuery(queryCaching);
        while (rowSet.next()) {
            contact=new Person();
            contact.setId(rowSet.getString("id"));
            contact.setName(rowSet.getString("name"));
            contact.setFirstName(rowSet.getString("firstname"));
            contact.setEmail(rowSet.getString("email"));
            contact.setPhone(rowSet.getString("mobilephone"));
            contactList.add(contact.getName()+" "+contact.getFirstName());
            contacts.add(contact);
        }
        Collections.sort(contactList);
        
        serviceSet.clear();
        queryCaching="SELECT mon_server FROM irmdb.computers WHERE mon_server IS NOT NULL";
        rowSet=sth.executeQuery(queryCaching);
        while (rowSet.next()) {
            String mon_server=rowSet.getString("mon_server");
            serviceSet.add(mon_server);
        }
        for(String mon_server: serviceSet) {
            monServers.add(mon_server);
        }
//        monServers.add("null");
        Collections.sort(monServers);
        sth.close();
    }
    
    private String convertCSV() {
        String header="\"id\",\"Name\",\"Group\",\"Location\",\"Rack\",\"Rack unit\",\"Serial\",\"Inv number\",\"Status\"\n";
        String content=""+header; String delimiter="\",\"";
        for (ComputerInfo comp: selectedComputers) {
            content+="\""+comp.getComputers_id()+delimiter+comp.getComputers_name()+delimiter+comp.getGroups_name()
                    +delimiter+comp.getLocations_name()+delimiter+comp.getRacks_name()+delimiter+comp.getComputers_rack_unit()
                    +delimiter+comp.getComputers_serial()+delimiter+comp.getComputers_inv_number()+delimiter
                    +comp.getComputers_status_name()+"\"\n";
        }
        return content;
    }
    
    private String nullify(String str) {
        if ((str==null) || (str.isEmpty())) {
            return "0";
        } else return str;
    }
}

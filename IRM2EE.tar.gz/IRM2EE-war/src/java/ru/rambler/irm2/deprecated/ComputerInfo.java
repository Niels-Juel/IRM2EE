/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.rambler.irm2.deprecated;

import java.sql.*;
import java.util.*;
import java.io.*;
import javax.servlet.http.Part;
import org.apache.commons.net.ftp.*;
import org.richfaces.event.*;
import org.richfaces.model.*;

/**
 *
 * @author a.shalin
 * @deprecated 
 */
@Deprecated
public class ComputerInfo implements Cloneable{
    private String computers_id, computers_name, locations_name, rack_id, racks_name, computers_rack_unit,
            computers_serial, computers_inv_number, computers_status_id, computers_status_name, groups_id, groups_name,
            models_id, models_name, vendor_id, vendor_name, ram, cpu, os, osver, osFullDesc, mb_manufact, mb_type, mbFullDesc,
            box_unit, contacts_id, contacts_name, contacts_firstname, displayName, contacts_email, contacts_mobilephone, comments,
            mon_fqdn, mon_server, isInLease;
    private java.util.Date buy_date, lease_expired, guarantee;
    private final String onMouseOver="document.getElementById(this.id+'_header').style.background='#60BA01';document.getElementById(this.id+'_body').style.background='#F4FFF8'";
    private final String onMouseOut="document.getElementById(this.id+'_header').style.background='#4C9600';document.getElementById(this.id+'_body').style.background='#E4FFC8'";
    private int index;
    private Connection dbhIrmdb;
    private final List<String> listRacks;
    private final List<String> listMacs;
    private final List<ScannedDocument> scannedDocuments;
    private Part fileToUpload;

    private ArrayList<UploadedImage> files;
    
    public String getIsInLease() {
        return isInLease;
    }
    
    public void setIsInLease(String isInLease) {
        this.isInLease=isInLease;
    }
    
    public List<String> getListMacs() {
        return listMacs;
    }
    
    public void putMac(String macAddress) {
        listMacs.add(macAddress);
    }
 
    public void paint(OutputStream stream, Object object) throws IOException {
        stream.write(getFiles().get((Integer) object).getData());
        stream.close();
    }
 
    public void uploadListener(FileUploadEvent event) throws Exception {
        UploadedFile item = event.getUploadedFile();
        UploadedImage file = new UploadedImage();
        file.setLength(item.getData().length);
        file.setName(item.getName());
        file.setData(item.getData());
        files.add(file);
    }
 
    public String clearUploadData() {
        files.clear();
        return null;
    }
 
    public int getSize() {
        if (getFiles().size() > 0) {
            return getFiles().size();
        } else {
            return 0;
        }
    }
 
    public long getTimeStamp() {
        return System.currentTimeMillis();
    }
 
    public ArrayList<UploadedImage> getFiles() {
        return files;
    }
 
    public void setFiles(ArrayList<UploadedImage> files) {
        this.files = files;
    }    
    
    @Override
    public ComputerInfo clone() throws CloneNotSupportedException {
        ComputerInfo mirror=new ComputerInfo();
        mirror.setComputers_id(computers_id);
        mirror.setComputers_name(computers_name);
        mirror.setLocations_name(locations_name);
        mirror.setRack_id(rack_id);
        mirror.setRacks_name(racks_name);
        mirror.setComputers_rack_unit(computers_rack_unit);
        mirror.setComputers_serial(computers_serial);
        mirror.setComputers_inv_number(computers_inv_number);
        mirror.setComputers_status_id(computers_status_id);
        mirror.setComputers_status_name(computers_status_name);
        mirror.setGroups_id(groups_id);
        mirror.setGroups_name(groups_name);
        mirror.setModels_id(models_id);
        mirror.setModels_name(models_name);
        mirror.setVendor_id(vendor_id);
        mirror.setVendor_name(vendor_name);
        mirror.setRam(ram);
        mirror.setCpu(cpu);
        mirror.setOs(os);
        mirror.setOsver(osver);
        mirror.setOsFullDesc(osFullDesc);
        mirror.setMb_manufact(mb_manufact);
        mirror.setMb_type(mb_type);
        mirror.setMbFullDesc(mbFullDesc);
        mirror.setBox_unit(box_unit);
        mirror.setContacts_id(contacts_id);
        mirror.setContacts_name(contacts_name);
        mirror.setContacts_email(contacts_email);
        mirror.setContacts_firstname(contacts_firstname);
        mirror.setContacts_mobilephone(contacts_mobilephone);
        mirror.setDisplayName(displayName);
        mirror.setComments(comments);
        mirror.setMon_fqdn(mon_fqdn);
        mirror.setMon_server(mon_server);
        return mirror;
    }
   
    /*There is some changes in RF 4.x interface.

        You have to use org.richfaces.event.FileUploadEvent instead UploadEvent, 
        and org.richfaces.model.UploadedFile instead UploadItem, like this:

        public void upload(FileUploadEvent event) throws IOException{
             UploadedFile file = event.getUploadedFile();
             ...
        }
     */
    
   
    public void changeLocation() {
    
    }
    
    public void changeContact() throws SQLException{
        String[] names=displayName.split("\\s+");
        String query="SELECT * FROM contacts WHERE name='"+names[0]+"' AND firstname='"+names[1]+"' LIMIT 1";
//        System.out.println(query);
        Statement sth=dbhIrmdb.createStatement();
        ResultSet rowSet=sth.executeQuery(query);
        while (rowSet.next()) {
            contacts_name=rowSet.getString("name");
            contacts_firstname=rowSet.getString("firstname");
            contacts_email=rowSet.getString("email");
            contacts_mobilephone=rowSet.getString("mobilephone");
        }
        sth.close();
    }
    
    public void filterRacks() throws SQLException {
        String queryRacks="SELECT \n" +
            "    racks.name\n" +
            "FROM\n" +
            "    racks\n" +
            "        LEFT JOIN\n" +
            "    locations ON location_id = locations.id\n" +
            "WHERE\n" +
            "    locations.name = '"+locations_name+"'";
        
        listRacks.clear();
        Statement sth=dbhIrmdb.createStatement();
        ResultSet rowSet=sth.executeQuery(queryRacks);
        while (rowSet.next()) {
            listRacks.add(rowSet.getString("name"));
        }
        sth.close();
        Collections.sort(listRacks);
    }
    
    public String getOnMouseOver() {
        return onMouseOver;
    }
    
    public String getOnMouseOut() {
        return onMouseOut;
    }
    
    public String getMon_server() {
        return mon_server;
    }
    
    public void setMon_server(String mon_server) {
        this.mon_server=mon_server;
    }
    
    public String getMon_fqdn() {
        return mon_fqdn;
    }
    
    public void setMon_fqdn(String mon_fqdn) {
        this.mon_fqdn=mon_fqdn;
    }
    
    public List<String> getListRacks() throws SQLException {
        filterRacks();
        return listRacks;
    }
    
    public String getDisplayName() {
        return displayName;
    }
    
    public void setDisplayName(String displayName) {
        this.displayName=displayName;
    }
    
    public int getIndex() {
        return index;
    }
    
    public void setIndex(int index) {
        this.index=index;
    }
    
    public String getComputers_id() {
        return computers_id;
    }
    
    public void setComputers_id(String computers_id) {
        this.computers_id=computers_id;
    }
    
    public String getComputers_name() {
        return computers_name;
    }
    
    public void setComputers_name(String computers_name) {
        this.computers_name=computers_name;
    }
    
    public String getLocations_name() {
        return locations_name;
    }
    
    public void setLocations_name(String locations_name) {
        this.locations_name=locations_name;
    }
    
    public String getRack_id() {
        return rack_id;
    }
    
    public void setRack_id(String rack_id) {
        this.rack_id=rack_id;
    }
    
    public String getRacks_name() {
        return racks_name;
    }
    
    public void setRacks_name(String racks_name) {
        this.racks_name=racks_name;
    }
    
    public String getComputers_rack_unit() {
        return computers_rack_unit;
    }
    
    public void setComputers_rack_unit(String computers_rack_unit) {
        this.computers_rack_unit=computers_rack_unit;
    }
    
    public String getComputers_serial() {
        return computers_serial;
    }
    
    public void setComputers_serial(String computers_serial) {
        this.computers_serial=computers_serial;
    }
    
    public String getComputers_inv_number() {
        return computers_inv_number;
    }
    
    public void setComputers_inv_number(String computers_inv_number) {
        this.computers_inv_number=computers_inv_number;
    }
    
    public String getComputers_status_name() {
        return computers_status_name;
    }
    
    public void setComputers_status_name(String computers_status_name) {
        this.computers_status_name=computers_status_name;
    }
    
    public String getComputers_status_id() {
        return computers_status_id;
    }
    
    public void setComputers_status_id(String computers_status_id) {
        this.computers_status_id=computers_status_id;
    }
    
    public String getGroups_id() {
        return groups_id;
    }
    
    public void setGroups_id(String groups_id) {
        this.groups_id=groups_id;
    }    
    
    public String getGroups_name() {
        return groups_name;
    }
    
    public void setGroups_name(String groups_name) {
        this.groups_name=groups_name;
    }

    public String getModels_id() {
        return models_id;
    }
    
    public void setModels_id(String models_id) {
        this.models_id=models_id;
    }
    
    public String getModels_name() {
        return models_name;
    }
    
    public void setModels_name(String models_name) {
        this.models_name=models_name;
    }
    
    public String getVendor_id() {
        return vendor_id;
    }
    
    public void setVendor_id(String vendor_id) {
        this.vendor_id=vendor_id;
    }
    
    public String getVendor_name() {
        return vendor_name;
    }
    
    public void setVendor_name(String vendor_name) {
        this.vendor_name=vendor_name;
    }
    
    public String getCpu() {
        return cpu;
    }
    
    public void setCpu(String cpu) {
        this.cpu=cpu;
    }
    
    public String getRam() {
        return ram;
    }
    
    public void setRam(String ram) {
        this.ram=ram;
    }
    
    public String getOs() {
        return os;
    }
    
    public void setOs(String os) {
        this.os=os;
    }
    
    public String getOsver() {
        return osver;
    }
    
    public void setOsFullDesc(String osFullDesc) {
        this.osFullDesc=osFullDesc;
    }
    
    public String getOsFullDesc() {
        return osFullDesc;
    }
    
    public void setOsver(String osver) {
        this.osver=osver;
    }
    
    public String getMb_manufact() {
        return mb_manufact;
    }
    
    public void setMb_manufact(String mb_manufact) {
        this.mb_manufact=mb_manufact;
    }
    
    public String getMb_type() {
        return mb_type;
    }
    
    public void setMb_type(String mb_type) {
        this.mb_type=mb_type;
    }
    
    public String getMbFullDesc() {
        return mbFullDesc;
    }
    
    public void setMbFullDesc(String mbFullDesc) {
        this.mbFullDesc=mbFullDesc;
    }
    
    public String getComments() {
        return comments;
    }
    
    public void setComments(String comments) {
        this.comments=comments;
    }
    
    public String getBox_unit() {
        return box_unit;
    }
    
    public void setBox_unit(String box_unit) {
        this.box_unit=box_unit;
    }
    
    public String getContacts_id() {
        return contacts_id;
    }
    
    public void setContacts_id(String contacts_id) {
        this.contacts_id=contacts_id;
    }
    
    public String getContacts_name() {
        return contacts_name;
    }
    
    public void setContacts_name(String contacts_name) {
        this.contacts_name=contacts_name;
    }
    
    public String getContacts_firstname() {
        return contacts_firstname;
    }
    
    public void setContacts_firstname(String contacts_firstname) {
        this.contacts_firstname=contacts_firstname;
    }
    
    public String getContacts_email() {
        return contacts_email;
    }
    
    public void setContacts_email(String contacts_email) {
        this.contacts_email=contacts_email;
    }
    
    public String getContacts_mobilephone() {
        return contacts_mobilephone;
    }
    
    public void setContacts_mobilephone(String contacts_mobilephone) {
        this.contacts_mobilephone=contacts_mobilephone;
    }
    
    public java.util.Date getGuarantee() {
        return guarantee;
    }
    
    public void setGuarantee(java.util.Date guarantee) {
        this.guarantee=guarantee;
    }
    
    public java.util.Date getLease_expired() {
        return lease_expired;
    }
    
    public void setLease_expired(java.util.Date lease_expired) {
        this.lease_expired=lease_expired;
    }    
    
    public java.util.Date getBuy_date() {
        return buy_date;
    }
    
    public void setBuy_date(java.util.Date buy_date) {
        this.buy_date=buy_date;
    }
    
    public void addScannedDocument(ScannedDocument filename) {
        scannedDocuments.add(filename);
    }
    
    public List<ScannedDocument> getScannedDocuments() {
        return scannedDocuments;
    }
    
    public Part getFileToUpload() {
        return fileToUpload;
    }
 
    public void setFileToUpload(Part fileToUpload) {
        this.fileToUpload = fileToUpload;
    }
    
    // Extract file name from content-disposition header of file part
    private String getFileName(Part part) {
        final String partHeader = part.getHeader("content-disposition");
        System.out.println("***** partHeader: " + partHeader);
        for (String content : part.getHeader("content-disposition").split(";")) {
            if (content.trim().startsWith("filename")) {
                return content.substring(content.indexOf('=') + 1).trim()
                        .replace("\"", "");
            }
        }
        return null;
    }
    
    public void uploadFtpServer() throws IOException{
        //String content=fileToUpload.getInputStream();
        String username="shalin";
        String password="fix5553728";
        
        FTPClient ftpClient = new FTPClient();
        FTPClientConfig ftpClientConfig = new FTPClientConfig();
        ftpClient.configure(ftpClientConfig);
        boolean error = false;
        try {
            int reply;
            String server = "mirror.rambler.ru";
            ftpClient.connect(server);
            ftpClient.login(username, password);
            reply = ftpClient.getReplyCode();
            if(!FTPReply.isPositiveCompletion(reply)) {
                ftpClient.disconnect(); 
                System.out.println("Disconnected");
            } 
            ftpClient.sendCommand("CWD", "scans");
            InputStream is = fileToUpload.getInputStream();
            ftpClient.enterLocalPassiveMode();
            ftpClient.setFileType(ftpClient.BINARY_FILE_TYPE, ftpClient.BINARY_FILE_TYPE);
            ftpClient.setFileTransferMode(ftpClient.BINARY_FILE_TYPE);
            Boolean test = ftpClient.storeFile(getFileName(fileToUpload), is);  //FTP store here
            System.out.println("Store file "+test);
            reply = ftpClient.getReplyCode();
            System.out.println("Reply code "+reply);
            is.close();
            ftpClient.logout();
        } catch(IOException e) {
            System.out.println("Something wrong");
        } finally {
            // ... not important
        }
    }
    
    public void clearScannedList() {
        scannedDocuments.clear();
    }
    
    public ComputerInfo() {
        index=0;
//        dbhIrmdb=AuthorizationTag.dbhIrmdb;
        listRacks=new ArrayList<>();
        files = new ArrayList<>();
        listMacs=new ArrayList<>();
        scannedDocuments=new ArrayList<>();
    }
}

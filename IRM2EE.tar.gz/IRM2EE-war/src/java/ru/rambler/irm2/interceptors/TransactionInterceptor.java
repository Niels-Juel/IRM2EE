/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.rambler.irm2.interceptors;

import java.util.logging.LogManager;
import java.util.logging.Logger;
import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;

/**
 *
 * @author a.shalin
 */
@Interceptor
@TransactionDebugger
public class TransactionInterceptor {
//    private Logger logger = LogManager.getLogger();
    
    @AroundInvoke
    public Object runInTransaction(InvocationContext invocationContext) throws Exception {
        Object result = null;
        try {
            result = invocationContext.proceed();
        } catch (Exception e) {
//            logger.error("Error encountered during Transaction.", e);
            System.out.println("Error encountered during Transaction.");
            throw e;
        }
        return result;
    }
}

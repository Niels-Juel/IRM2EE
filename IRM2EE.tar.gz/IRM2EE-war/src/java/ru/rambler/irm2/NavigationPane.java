/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ru.rambler.irm2;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.*;
import static java.security.AccessController.getContext;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.ServletContext;
import javax.xml.bind.JAXBException;
import javax.xml.transform.stream.StreamSource;


/**
 *
 * @author a.shalin
 */
@Named(value = "navigationPane")
@SessionScoped
public class NavigationPane implements Serializable {
    @Inject
    ScheduledTasks scheduledTasks;
    
    public void logout() {
        FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
    }
    /**
     * Creates a new instance of NavigationPane
     */
    public NavigationPane() {
    }
    
    public void checkDiscs() {
        scheduledTasks.verifyDiskStore();
    }
    
    public void testMarshaller() throws JAXBException {
        scheduledTasks.testMarshaller();
    }
    
    public void checkServers() {
        scheduledTasks.checkServers();
    }
}
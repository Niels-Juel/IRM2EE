/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.rambler.irm2;

import com.google.common.collect.HashBiMap;
import ru.rambler.irm2.entries.Contacts;
import ru.rambler.irm2.entries.Groups;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

/**
 *
 * @author a.shalin
 */
@Named(value = "groupHandler")
@ViewScoped
public class GroupHandler implements Serializable{
    @Inject
    private AuthorizationTag authorizationTag;
    
    private EntityManager entityManager;
    private List<Groups> groupsList;
//    private List<Contacts> contactsList;
    private boolean massBehavior;
    private List<String> contactNameList;
    private String chosenContact;
    private Map<Integer, Contacts> contactMap;

    public List<Groups> getGroupsList() {
        return groupsList;
    }

    public String getChosenContact() {
        return chosenContact;
    }

    public void setChosenContact(String chosenContact) {
        this.chosenContact = chosenContact;
    }

    public List<String> getContactNameList() {
        return contactNameList;
    }
    
    /**
     * Creates a new instance of GroupHandler
     */
    public GroupHandler() {
        massBehavior=false;
        chosenContact=" ";
    }
    
    public void massCheckUncheck() {
        massBehavior=!massBehavior;
        for (Groups group: groupsList) {
            group.setChecked(massBehavior);
        }
    }
    
    public void refreshContacts() {
        Query query=entityManager.createNamedQuery("Contacts.findAll");
        List<Contacts> contactsList=query.getResultList();
        contactNameList=new ArrayList<>(); contactMap=new HashMap<>();
        contactNameList.add(" ");
        for (Contacts contact: contactsList) {
            contactNameList.add(contact.getName()+" "+contact.getFirstname());
            contactMap.put(contact.getId(), contact);
        }
    }
    
    public void refreshGroups() {
        for (Groups group: groupsList) {
            Contacts contact=contactMap.get(group.getContact_id());
            group.setDisplayManagerName(contact.getName()+" "+contact.getFirstname());
        }
    }
    
    @Transactional(Transactional.TxType.REQUIRED)
    public void bindGroups() {
        if (!chosenContact.equals(" ")) {
            Query query=entityManager.createQuery("SELECT c FROM Contacts c WHERE CONCAT(c.name,' ',c.firstname)=:chosen_name");
            query.setParameter("chosen_name", chosenContact).setMaxResults(1);
            List<Contacts> contacts=query.getResultList();
            
            if (!contacts.isEmpty()) {
                Contacts contact=contacts.get(0);
                        
                for (Groups group: groupsList) {
                    if (group.getChecked()) {
                        int id=group.getId();
                        group.setContact_id(contact.getId());
                        entityManager.merge(group); entityManager.detach(group); group=null;
                        group=entityManager.find(Groups.class, id);
                    }
                }
            }
            refreshGroups();
        }
    }
    
    @PostConstruct
    private void postConstructChores() {
        entityManager=authorizationTag.getEntityManager();

        Query query=entityManager.createNamedQuery("Groups.findAll");
        groupsList=query.getResultList();
        refreshContacts(); refreshGroups();
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ru.rambler.irm2;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.*;
import java.sql.*;

/**
 *
 * @author a.shalin
 */
@Named(value = "partItemConstructor")
@SessionScoped
public class PartItemConstructor implements Serializable {
    private String chosenManufacturer, chosenPart, chosenCategory, chosenVendor, serial, comment, serviceMessages;
    private final List<String> listParts, listCategories, listVendors, listManufacturers, listToInsert;
    private final Map<String, Integer> mapParts, mapCategories, mapVendors;
    private java.util.Date warranty;
    private Connection dbhIrmdb;
    private boolean isTested;
    
    public void insertSerials() throws SQLException {
        testSerials();
        for(String currentSerialNumber: listToInsert) {
            PreparedStatement commonInsert=null;
            try {
                String queryInsertPart="INSERT INTO store (part_id, category_id, vendor_id, serial, comment, warranty) VALUES (?, ?, ?, ?, ?, ?)";
                dbhIrmdb.setAutoCommit(false);
                commonInsert=dbhIrmdb.prepareStatement(queryInsertPart);
                commonInsert.setInt(1, (int) mapParts.get(chosenPart));
                commonInsert.setInt(2, (int) mapCategories.get(chosenCategory));
                commonInsert.setInt(3, (int) mapVendors.get(chosenVendor));
                commonInsert.setString(4, currentSerialNumber);
                commonInsert.setString(5, comment);
                commonInsert.setDate(6, new java.sql.Date(warranty.getTime()));
                commonInsert.executeUpdate();
                dbhIrmdb.commit();
                serviceMessages+=(currentSerialNumber+" is inserted successfully\n");
            } catch (SQLException ex) {
                System.out.println(ex.getStackTrace().toString());
                try {
                    System.err.print("Transaction is being rolled back");
                    dbhIrmdb.rollback();
                    ex.printStackTrace();
                } catch(SQLException excep) {
                    excep.printStackTrace();
                }
            } finally {
                if (commonInsert != null) {
                    commonInsert.close();
                }
                dbhIrmdb.setAutoCommit(true);
            }
        }
    }
    
    public void testSerials() throws SQLException {
        isTested=true; serviceMessages="";
        String[] serialNumbers=serial.split("\\s+");
        for (String currentSerialNumber: serialNumbers) {
            int collisions=0;
            String queryService="SELECT * FROM store WHERE UCASE(serial)='"+currentSerialNumber+"'";
            Statement sth=dbhIrmdb.createStatement();
            ResultSet rowSet=sth.executeQuery(queryService);
            while (rowSet.next()) {
                collisions++;
            }
            if (collisions>0) {
                serviceMessages+=(currentSerialNumber+" already exist in irmdb.store\n");
            } else {
                listToInsert.add(currentSerialNumber);
            }
            rowSet.close();
            sth.close();
        }
    }
    
    public void filterParts() throws SQLException{
        listParts.clear();
        if(!chosenManufacturer.isEmpty()) {
            String queryService="SELECT \n" +
                "    parts.name as parts_name\n" +
                "FROM\n" +
                "    parts\n" +
                "        LEFT JOIN\n" +
                "    manufacturers ON parts.manufacturer_id = manufacturers.id\n" +
                "WHERE\n" +
                "    manufacturers.name = '"+chosenManufacturer+"'";
            Statement sth=dbhIrmdb.createStatement();
            ResultSet rowSet=sth.executeQuery(queryService);
            while (rowSet.next()) {
                listParts.add(rowSet.getString("parts_name"));
            }
            Collections.sort(listParts);
            
            rowSet.close();
        }
    }
    
    public String getChosenManufacturer() {
        return chosenManufacturer;
    }
    
    public void setChosenManufacturer(String chosenManufacturer) {
        this.chosenManufacturer=chosenManufacturer;
    }
    
    public String getChosenPart() {
        return chosenPart;
    }
    
    public void setChosenPart(String chosenPart) {
        this.chosenPart=chosenPart;
    }
    
    public String getChosenCategory() {
        return chosenCategory;
    }
    
    public void setChosenCategory(String chosenCategory) {
        this.chosenCategory=chosenCategory;
    }
    
    public String getChosenVendor() {
        return chosenVendor;
    }
    
    public void setChosenVendor(String chosenVendor) {
        this.chosenVendor=chosenVendor;
    }
    
    public String getSerial() {
        return serial;
    }
    
    public void setSerial(String serial) {
        this.serial=serial.toUpperCase();
    }
    
    public String getComment() {
        return comment;
    }
    
    public void setComment(String comment) {
        this.comment=comment;
    }
    
    public String getServiceMessages() {
        return serviceMessages;
    }
    
    public void setServiceMessages(String serviceMessages) {
        this.serviceMessages=serviceMessages;
    }
    
    public List<String> getListParts() {
        return listParts;
    }

    public List<String> getListCategories() {
        return listCategories;
    }
    
    public List<String> getListVendors() {
        return listVendors;
    }
    
    public List<String> getListManufacturers() {
        return listManufacturers;
    }
    
    public java.util.Date getWarranty() {
        return warranty;
    }
    
    public boolean getIsTested() {
        return isTested;
//        return true;
    }
    
    public void setWarranty(java.util.Date warranty) {
        this.warranty=warranty;
    }
    /**
     * Creates a new instance of PartModelConstructor
     * @throws java.sql.SQLException
     */
    public PartItemConstructor() throws SQLException{
        isTested=true;
        
        listParts=new ArrayList<>();
        listCategories=new ArrayList<>();
        listVendors=new ArrayList<>();
        listManufacturers=new ArrayList<>();
        listToInsert=new ArrayList<>();
        
        mapParts=new HashMap<>();
        mapCategories=new HashMap<>();
        mapVendors=new HashMap<>();
        
//        dbhIrmdb=AuthorizationTag.dbhIrmdb;
        
        String queryService="SELECT * FROM manufacturers";
        Statement sth=dbhIrmdb.createStatement();
        ResultSet rowSet=sth.executeQuery(queryService);
        while (rowSet.next()) {
            listManufacturers.add(rowSet.getString("name"));
        }
        Collections.sort(listManufacturers);
        rowSet.close();
        sth.close();
        
        queryService="SELECT * FROM companies";
        sth=dbhIrmdb.createStatement();
        rowSet=sth.executeQuery(queryService);
        while (rowSet.next()) {
            listVendors.add(rowSet.getString("name"));
            mapVendors.put(rowSet.getString("name"), rowSet.getInt("id"));
        }
        Collections.sort(listVendors);
        rowSet.close();
        sth.close();
        
        queryService="SELECT * FROM parts";
        sth=dbhIrmdb.createStatement();
        rowSet=sth.executeQuery(queryService);
        while (rowSet.next()) {
            mapParts.put(rowSet.getString("name"), rowSet.getInt("id"));
        }
        rowSet.close();
        sth.close();
        
        queryService="SELECT * FROM category";
        sth=dbhIrmdb.createStatement();
        rowSet=sth.executeQuery(queryService);
        while (rowSet.next()) {
            listCategories.add(rowSet.getString("name"));
            mapCategories.put(rowSet.getString("name"), rowSet.getInt("id"));
        }
        Collections.sort(listCategories);
        rowSet.close();
        sth.close();
    }
}

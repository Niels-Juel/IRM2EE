/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.rambler.irm2;

import ru.rambler.irm2.entries.Locations;
import ru.rambler.irm2.entries.ComputerStatus;
import ru.rambler.irm2.entries.PartTypes;
import ru.rambler.irm2.entries.Groups;
import ru.rambler.irm2.entries.Manufacturers;
import java.io.IOException;
import java.io.Serializable;
import java.util.*;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.event.ActionEvent;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

/**
 *
 * @author a.shalin
 */
@Named(value = "authorizationTag")
@SessionScoped
public class AuthorizationTag implements Serializable {
    @EJB
    private ConnectorDB connectorDB;
    
//    @PersistenceContext(unitName = "IRM2EE-ejbPU", type=PersistenceContextType.TRANSACTION)
    private EntityManager entityManager;

    private String login, password, authMethod;
    private final CloseableHttpClient httpClient;
    private final HttpClientContext context;
    private final HttpHost targetHost;
    
    private List<Groups> groups;
    private List<Locations> locations;
    private List<PartTypes> partTypes;
    private List<Manufacturers> manufacturers;
    private List<String> statusList;

    public List<PartTypes> getPartTypes() {
        return partTypes;
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

    public List<Groups> getGroups() {
        return groups;
    }

    public List<Locations> getLocations() {
        return locations;
    }

    public List<Manufacturers> getManufacturers() {
        return manufacturers;
    }
    
    public String getLogin() {
        return login;
    }
    
    public void setLogin(String login) {
        this.login=login;
    }
    
    public String getPassword() {
        return "";
    }
    
    public void setPassword(String password) {
        this.password=password;
    }  
    
    public String getAuthMethod() {
        return authMethod;
    }
    
    public void setAuthMethod(String authMethod) {
        this.authMethod=authMethod;
    }

    public List<String> getStatusList() {
        return statusList;
    }

    public synchronized String authorizeJPA() throws IOException {
        if (authMethod.equals("AD")) {
            Credentials defaultCreds=new UsernamePasswordCredentials(login, password);

            CredentialsProvider credsProvider=new BasicCredentialsProvider();
            credsProvider.setCredentials(new AuthScope(targetHost.getHostName(), targetHost.getPort()), defaultCreds);

            //Create AutoCash instance
            AuthCache authCache=new BasicAuthCache();
            BasicScheme basicAuth=new BasicScheme();
            authCache.put(targetHost, basicAuth);

            //Add AuthCache to the execution context
            //HttpClientContext context=HttpClientContext.create();
            context.setCredentialsProvider(credsProvider);
            context.setAuthCache(authCache);

            HttpGet httpGet=new HttpGet("/rest/api/2/issue/TESTWORK-7");
            CloseableHttpResponse response=httpClient.execute(targetHost, httpGet, context);

//            if (response.getStatusLine().getStatusCode()==200) {
//                connectDB();
                return "NavigationPane";
//            } else {
//                return null;
//            }
        } else {
            return null;
        }
    }
    
    public static String getActionAttribute(ActionEvent event, String name) {
        return (String) event.getComponent().getAttributes().get(name);
    }
    
    public AuthorizationTag() {
        login="";
        password="";
        authMethod="AD";
        context=HttpClientContext.create();
        httpClient=HttpClients.createDefault();
        targetHost=new HttpHost("jira.rambler.ru", 443, "https");
    }
    
//    @PreDestroy
//    private void cleanUp() {
//        entityManager.close();
//    }
    
    @PostConstruct
    private void postConstructChores() {
        entityManager=connectorDB.getEntityManager();
        
        Query query = entityManager.createNamedQuery("Groups.findAll");
        groups = query.getResultList();
        Collections.sort(groups);

        query = entityManager.createNamedQuery("Locations.findAll");
        locations = query.getResultList();
        Collections.sort(locations);

        query = entityManager.createNamedQuery("PartTypes.findAll");
        partTypes = query.getResultList();
        Collections.sort(partTypes);

        query = entityManager.createNamedQuery("Manufacturers.findAll");
        manufacturers = query.getResultList();
        Collections.sort(manufacturers);
        
        statusList=new ArrayList<>();
        query = entityManager.createNamedQuery("ComputerStatus.findAll");
        List<ComputerStatus> statuses = query.getResultList();
        for (ComputerStatus status: statuses) {
            statusList.add(status.getName());
        }
        Collections.sort(statusList);
    }
}

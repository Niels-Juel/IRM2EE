
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ru.rambler.irm2;

import ru.rambler.irm2.entries.*;
import java.io.Serializable;
import java.util.*;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

/**
 *
 * @author a.shalin
 */
@Named
@ViewScoped
@Transactional(Transactional.TxType.REQUIRED)
public class CompSearchJPA implements Serializable{
    @Inject
    private AuthorizationTag authorizationTag;
    
    private EntityManager entityManager;

    @EJB
    private CentralPoint centralPoint;

    private final String baseRequest="SELECT comp FROM Computers comp WHERE comp.devtypeId=1";
    private final String standardSortOrder=" ORDER BY comp.rack.location.name, comp.rack.name, comp.name, comp.rackUnit";

    private String nameServer, serialServer, invServer, serialParts, ram, sortOrder;
    private List<Computers> selectedComputers;
    private List<String> chosenGroups, chosenLocations, chosenRacks, chosenTypes, chosenManufacturers, chosenParts;
    private List<String> cpuModels, chosenCpuModels, moboModels, chosenMoboModels, compModels, chosenCompModels;
    private List<Groups> groups;
    private List<Locations> locations;
    private List<PartTypes> partTypes;
    private List<Racks> racks;
    private List<Manufacturers> manufacturers;
    private List<Parts> parts;

    public String getNameServer() {
        return nameServer;
    }

    public void setNameServer(String nameServer) {
        this.nameServer = nameServer;
    }

    public String getSerialServer() {
        return serialServer;
    }

    public void setSerialServer(String serialServer) {
        this.serialServer = serialServer;
    }

    public String getInvServer() {
        return invServer;
    }

    public void setInvServer(String invServer) {
        this.invServer = invServer;
    }

    public String getSerialParts() {
        return serialParts;
    }

    public void setSerialParts(String serialParts) {
        this.serialParts = serialParts;
    }

    public String getRam() {
        return ram;
    }

    public void setRam(String ram) {
        this.ram = ram;
    }

    public List<Computers> getSelectedComputers() {
        return selectedComputers;
    }

    public List<String> getChosenGroups() {
        return chosenGroups;
    }

    public void setChosenGroups(List<String> chosenGroups) {
        this.chosenGroups = chosenGroups;
    }

    public List<String> getChosenLocations() {
        return chosenLocations;
    }

    public void setChosenLocations(List<String> chosenLocations) {
        this.chosenLocations = chosenLocations;
    }

    public List<String> getChosenRacks() {
        return chosenRacks;
    }

    public void setChosenRacks(List<String> chosenRacks) {
        this.chosenRacks = chosenRacks;
    }

    public List<String> getChosenTypes() {
        return chosenTypes;
    }

    public void setChosenTypes(List<String> chosenTypes) {
        this.chosenTypes = chosenTypes;
    }

    public List<String> getChosenManufacturers() {
        return chosenManufacturers;
    }

    public void setChosenManufacturers(List<String> chosenManufacturers) {
        this.chosenManufacturers = chosenManufacturers;
    }

    public List<String> getChosenParts() {
        return chosenParts;
    }

    public void setChosenParts(List<String> chosenParts) {
        this.chosenParts = chosenParts;
    }

    public List<String> getChosenCpuModels() {
        return chosenCpuModels;
    }

    public void setChosenCpuModels(List<String> chosenCpuModels) {
        this.chosenCpuModels = chosenCpuModels;
    }

    public List<String> getChosenMoboModels() {
        return chosenMoboModels;
    }

    public void setChosenMoboModels(List<String> chosenMoboModels) {
        this.chosenMoboModels = chosenMoboModels;
    }

    public List<Groups> getGroups() {
        return groups;
    }

    public List<Locations> getLocations() {
        return locations;
    }

    public List<Racks> getRacks() {
        return racks;
    }

    public List<PartTypes> getPartTypes() {
        return partTypes;
    }

    public List<Manufacturers> getManufacturers() {
        return manufacturers;
    }

    public List<Parts> getParts() {
        return parts;
    }

    public List<String> getCpuModels() {
        return cpuModels;
    }

    public List<String> getMoboModels() {
        return moboModels;
    }

    public List<String> getCompModels() {
        return compModels;
    }

    public List<String> getChosenCompModels() {
        return chosenCompModels;
    }

    public void setChosenCompModels(List<String> chosenCompModels) {
        this.chosenCompModels = chosenCompModels;
    }

    public void clearControls() {
        nameServer=null; serialServer=null; invServer=null; serialParts=null; ram=null;
        chosenGroups.clear(); chosenLocations.clear(); chosenRacks.clear();
        if (racks!=null) {
            racks.clear();
        }
        if (selectedComputers!=null) {
            selectedComputers.clear();
        }
        chosenTypes.clear();
        manufacturers.clear();
        chosenManufacturers.clear();
        if (parts!=null) {
            parts.clear();
        }
        chosenParts.clear();
        chosenCpuModels.clear();
        chosenMoboModels.clear();

        sortOrder=standardSortOrder;
    }

    public void submitSearch() {
        Map<String, List<String>> queryParameters=new HashMap<>();

        String completeRequest=baseRequest;

        if(!nameServer.isEmpty()) {
            completeRequest+=" AND comp.name IN :compNames";
            queryParameters.put("compNames", centralPoint.parse(nameServer));
        }

        if(!serialServer.isEmpty()) {
            completeRequest+=" AND comp.serial IN :compSerials";
            queryParameters.put("compSerials", centralPoint.parse(serialServer));
        }

        if(!invServer.isEmpty()) {
            completeRequest+=" AND comp.invNumber IN :compInvNumbers";
            queryParameters.put("compInvNumbers", centralPoint.parse(invServer));
        }

        if (!chosenGroups.isEmpty()) {
            completeRequest+=" AND comp.group.name IN :groupNames";
            queryParameters.put("groupNames", chosenGroups);
        }

        if (chosenRacks.isEmpty() && (!chosenLocations.isEmpty())) {
            completeRequest+=" AND comp.rack.location.name IN :locNames";
            queryParameters.put("locNames", chosenLocations);
        }

        if (!chosenRacks.isEmpty()) {
            completeRequest+=" AND comp.rack.name IN :rackNames";
            queryParameters.put("rackNames", chosenRacks);
        }

        if (!chosenCpuModels.isEmpty()) {
            completeRequest+=" AND comp.cpu IN :cpuModels";
            queryParameters.put("cpuModels", chosenCpuModels);
        }

        if (!chosenMoboModels.isEmpty()) {
            completeRequest+=" AND CONCAT(comp.mbManufact,' ',comp.mbType) IN :moboModels";
            queryParameters.put("moboModels", chosenMoboModels);
        }

        if (!chosenCompModels.isEmpty()) {
            completeRequest+=" AND comp.model.name in :compModels";
            queryParameters.put("compModels", chosenCompModels);
        }
        
        if (!chosenParts.isEmpty() || !serialParts.isEmpty()) {
            Query query;

            if (serialParts.isEmpty()) {
                String searchQuery="SELECT s FROM Store s WHERE s.part.name IN :names AND s.computer_id IS NOT NULL";
                query=entityManager.createQuery(searchQuery).setParameter("names", chosenParts);
            } else {
                String searchQuery="SELECT s FROM Store s WHERE s.serial IN :serials AND s.computer_id IS NOT NULL";
                query=entityManager.createQuery(searchQuery).setParameter("serials", centralPoint.parse(serialParts));
            }

            List<Store> storeItems=query.getResultList();
            Set<String> compIDs=new HashSet<>();
            for (Store storeItem: storeItems) {
                if (storeItem.getComputer_id()!=null) {
                    compIDs.add(Integer.toString(storeItem.getComputer_id()));
                }
            }

            List<String> compIDsList=new ArrayList<>();
            for (String id: compIDs) {
                compIDsList.add(id);
            }

            if (compIDsList.isEmpty()) {
                compIDsList.add("-1488");
            }
            completeRequest+=" AND comp.id IN :compIDs";
            queryParameters.put("compIDs", compIDsList);
        }

        if (ram!=null && !ram.isEmpty()) {
            completeRequest+=" AND comp.ram >= :ram";
//            queryParameters.put("ram", ram);
        }

        completeRequest+=sortOrder;

        Query query=entityManager.createQuery(completeRequest);

        Iterator it = queryParameters.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pairsParams = (Map.Entry)it.next();
            if (!pairsParams.getValue().equals("")) {
                String paramName=(String) pairsParams.getKey();
                List paramValue=(List) pairsParams.getValue();
                query.setParameter(paramName, paramValue);
            }
        }

        if (ram!=null && !ram.isEmpty()) {
            query.setParameter("ram", ram);
        }

        selectedComputers=query.getResultList();
        for(Computers comp: selectedComputers) {
            entityManager.detach(comp);
        }
    }

    public void sortById() {
        sortOrder=" ORDER BY comp.id";
        submitSearch();
    }

    public void sortByName() {
        sortOrder=" ORDER BY comp.name";
        submitSearch();
    }

    public void sortByGroup() {
        sortOrder=" ORDER BY comp.group.name";
        submitSearch();
    }

    public void sortByLocation() {
        sortOrder=" ORDER BY comp.rack.location.name";
        submitSearch();
    }

    public void sortByRack() {
        sortOrder=" ORDER BY comp.rack.name";
        submitSearch();
    }

    public void sortBySerial() {
        sortOrder=" ORDER BY comp.serial";
        submitSearch();
    }

    public void sortByInvNumber() {
        sortOrder=" ORDER BY comp.invNumber";
        submitSearch();
    }

    public void filterRacks() {
        Query query = entityManager.createNamedQuery("Racks.findByLocations").setParameter("locNames", chosenLocations);
        racks = query.getResultList();
        Collections.sort(racks);
    }

    public void filterManufacturers() {
        Set<Manufacturers> setManuf=new HashSet<>();
        Query query = entityManager.createNamedQuery("Parts.findByTypes").setParameter("types", chosenTypes);
        List<Parts> listParts = query.getResultList();
        for (Parts partItem: listParts) {
            setManuf.add(partItem.getManufacturer());
        }
        manufacturers.clear();
        for (Manufacturers manufacturer: setManuf) {
            manufacturers.add(manufacturer);
        }
        Collections.sort(manufacturers);
    }

    public void filterParts() {
        if (!chosenTypes.isEmpty() && !chosenManufacturers.isEmpty()) {
            String searchQuery="SELECT p FROM Parts p WHERE p.partType.name IN :types AND p.manufacturer.name IN :manufs";
            Query query=entityManager.createQuery(searchQuery);
            query.setParameter("types", chosenTypes);
            query.setParameter("manufs", chosenManufacturers);
            parts=query.getResultList();
            Collections.sort(parts);
        }
    }

    public CompSearchJPA() {
        chosenGroups=new ArrayList<>();
        chosenLocations=new ArrayList<>();
        chosenRacks=new ArrayList<>();
        chosenTypes=new ArrayList<>();
        manufacturers=new ArrayList<>(); //AuthorizationTag.getManufacturers();
        chosenManufacturers=new ArrayList<>();
        chosenParts=new ArrayList<>();
        chosenCpuModels=new ArrayList<>();
        chosenMoboModels=new ArrayList<>();
        ram=null;
        sortOrder=standardSortOrder;
    }

    private void initCpuList() {
        cpuModels=new ArrayList<>();

        String findCpuModels="SELECT c FROM Computers c WHERE c.cpu IS NOT NULL";
        Query query=entityManager.createQuery(findCpuModels);
        List<Computers> compList=query.getResultList();
        Set<String> cpuSet=new HashSet<>();
        for (Computers comp: compList) {
            cpuSet.add(comp.getCpu());
        }

        for (String cpuModel: cpuSet) {
            cpuModels.add(cpuModel);
        }

        Collections.sort(cpuModels);
    }

    private void initMoboList() {
        moboModels=new ArrayList<>();

        String findCpuModels="SELECT c FROM Computers c WHERE c.mbManufact IS NOT NULL AND c.mbType IS NOT NULL";

        Query query=entityManager.createQuery(findCpuModels);
        List<Computers> compList=query.getResultList();
        Set<String> moboSet=new HashSet<>();
        for (Computers comp: compList) {
            moboSet.add(comp.getMbManufact()+" "+comp.getMbType());
        }

        for (String cpuModel: moboSet) {
            moboModels.add(cpuModel);
        }

        Collections.sort(moboModels);
    }
    
    @PostConstruct
    private void postConstructChores() {
        entityManager=authorizationTag.getEntityManager();
        initCpuList();
        initMoboList();
        
        groups=authorizationTag.getGroups();
        locations=authorizationTag.getLocations();
        partTypes=authorizationTag.getPartTypes();
        
        compModels=new ArrayList<>();
        Query query=entityManager.createNamedQuery("Models.findAll");
        List<Models> modelsList=query.getResultList();
        for (Models model: modelsList) {
            compModels.add(model.getName());
        }
    }
}
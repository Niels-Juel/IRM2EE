/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ru.rambler.irm2;

import ru.rambler.irm2.entries.Boxes;
import ru.rambler.irm2.entries.Replaces;
import ru.rambler.irm2.entries.Store;
import ru.rambler.irm2.entries.Computers;
import ru.rambler.irm2.entries.EventLog;
import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.*;
import javax.transaction.Transactional;

/**
 *
 * @author a.shalin
 */
@Named(value = "diskBinder")
@ViewScoped
public class DiskBinder implements Serializable{
    @Inject
    private AuthorizationTag authorizationTag;
    private EntityManager entityManager;
    
    private String hddSerials, bindingMode, nameServerBox;
    private List<Boxes> foundBoxes;
    private List<Computers> foundComputers;
    private Integer idServerBox, invNumber;

    public String getHddSerials() {
        return hddSerials;
    }

    public void setHddSerials(String hddSerials) {
        this.hddSerials = hddSerials;
    }

    public String getBindingMode() {
        return bindingMode;
    }

    public void setBindingMode(String bindingMode) {
        this.bindingMode = bindingMode;
    }

    public String getNameServerBox() {
        return nameServerBox;
    }

    public void setNameServerBox(String nameServerBox) {
        this.nameServerBox = nameServerBox;
    }

    public Integer getIdServerBox() {
        return idServerBox;
    }

    public void setIdServerBox(Integer idServerBox) {
        this.idServerBox = idServerBox;
    }

    public Integer getInvNumber() {
        return invNumber;
    }

    public void setInvNumber(Integer invNumber) {
        this.invNumber = invNumber;
    }

    public List<Boxes> getFoundBoxes() {
        return foundBoxes;
    }

    public List<Computers> getFoundComputers() {
        return foundComputers;
    }
    
    /**
     * Creates a new instance of DiskBinder
     */
    public DiskBinder() {
        bindingMode="Server";
    }
    
    @PostConstruct
    private void postConstructChores() {
        entityManager=authorizationTag.getEntityManager();
    }
    
    public void lookup() {
        foundBoxes=null;
        foundComputers=null;
        if (nameServerBox==null || nameServerBox.isEmpty()) {
            nameServerBox="Kaileena"; //Magic word
        }
        if (bindingMode.equals("Server")) {
            String lookupQueryString="SELECT c FROM Computers c WHERE c.id = :id OR c.name LIKE :name OR c.invNumber=:invNumber";
            Query lookupQuery=entityManager.createQuery(lookupQueryString);
            lookupQuery.setParameter("id", idServerBox);
            lookupQuery.setParameter("name", nameServerBox+"%");
            lookupQuery.setParameter("invNumber", invNumber);
            foundComputers=lookupQuery.getResultList();
        } else {
            String lookupQueryString="SELECT b FROM Boxes b WHERE b.id = :id OR b.name LIKE :name";
            Query lookupQuery=entityManager.createQuery(lookupQueryString);
            lookupQuery.setParameter("id", idServerBox);
            lookupQuery.setParameter("name", nameServerBox+"%");
            foundBoxes=lookupQuery.getResultList();
        }
    }
    
    /**
     *Submit disk binding to the database
     */
    @Transactional(Transactional.TxType.REQUIRED)
    public void bindDisks() {
        Date currentDate=new Date(); 
        Calendar currentDateCal=new GregorianCalendar();
        currentDateCal.setTime(currentDate);
        
        Map<String, String> params=FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
        Integer idInteger=Integer.parseInt(params.get("id"));

        List<String> serialNums=CentralPoint.parse(hddSerials);
        
        String queryEntriesForUpdateString="SELECT s FROM Store s WHERE s.serial IN :serials";
        Query queryEntriesForUpdate=entityManager.createQuery(queryEntriesForUpdateString).setParameter("serials", serialNums);
        List<Store> disksToUpdateList=queryEntriesForUpdate.getResultList();
        
        if (bindingMode.equals("Server")) {
            for (Store diskEntry: disksToUpdateList) {
                //New Replace entry
                Replaces replaceEntry=new Replaces();
                replaceEntry.setComputerId(idInteger);
                replaceEntry.setDate(currentDate);
                replaceEntry.setUser(authorizationTag.getLogin());
                replaceEntry.setAddId(diskEntry.getId());
                entityManager.persist(replaceEntry);
                
                //New Ebtry_logs entry
                EventLog eventLog=new EventLog();
                eventLog.setDate(currentDate);
                eventLog.setItemtype("store");
                eventLog.setService("база данных");
                eventLog.setLevel((short) 4);
                eventLog.setAction("update");
                eventLog.setUser(authorizationTag.getLogin());
                eventLog.setMessage("box_id='"+nullify(diskEntry.getBoxId())+"'->");
                
                diskEntry.setBoxId(null);
                diskEntry.setComputer_id(idInteger);
                diskEntry.setSt_timestamp(currentDateCal);
            }
        } else {
            for (Store diskEntry: disksToUpdateList) {
                Replaces replaceEntry=new Replaces();
                replaceEntry.setComputerId(diskEntry.getComputer_id());
                replaceEntry.setDate(currentDate);
                replaceEntry.setUser(authorizationTag.getLogin());
                replaceEntry.setRemoveId(diskEntry.getId());
                entityManager.persist(replaceEntry);
                
                //New Ebtry_logs entry
                EventLog eventLog=new EventLog();
                eventLog.setDate(currentDate);
                eventLog.setItemtype("store");
                eventLog.setService("база данных");
                eventLog.setLevel((short) 4);
                eventLog.setAction("update");
                eventLog.setUser(authorizationTag.getLogin());
                
                diskEntry.setBoxId(idInteger);
                diskEntry.setComputer_id(null);
                diskEntry.setSt_timestamp(currentDateCal);
            }
        }
    }
    
    public void checkDiskHistory() {
        List<String> serialNums=CentralPoint.parse(hddSerials);
    }
    
    private String nullify(Integer source) {
        if (source==null) {
            return "";
        } else return source.toString();
    }
    
}

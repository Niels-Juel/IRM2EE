/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.rambler.irm2;

import ru.rambler.irm2.entries.ModelParts;
import ru.rambler.irm2.entries.Models;
import ru.rambler.irm2.entries.ModelTypes;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

/**
 *
 * @author a.shalin
 */
@Named(value = "modelConstructor")
@ViewScoped
public class ModelConstructor implements Serializable{
    @Inject
    private AuthorizationTag authorizationTag;
    private EntityManager entityManager;
    private Models model;
    private boolean isExist;
    private List<String> modelTypesList;
    private String chosenModelType;
    private List<ModelParts> attachedParts;

    public Models getModel() {
        return model;
    }

    public List<String> getModelTypesList() {
        return modelTypesList;
    }

    public String getChosenModelType() {
        return chosenModelType;
    }

    public void setChosenModelType(String chosenModelType) {
        this.chosenModelType = chosenModelType;
    }

    public List<ModelParts> getAttachedParts() {
        return attachedParts;
    }
    
    public ModelConstructor() {
        //modelTypesList=new ArrayList<>();
    }

    public void checkModelName() {
        entityManager=authorizationTag.getEntityManager();
        Query query=entityManager.createNamedQuery("Models.findByName");
        query.setParameter("name", model.getName());
        if (!query.getResultList().isEmpty()) {
            throw new ValidatorException(new FacesMessage("Model name is not unique!"));
        }
    }
    
    public void submitForm() {
    
    }
    
    public void removeModelPartFromList() {
        FacesContext facesContext=FacesContext.getCurrentInstance();
        Integer modelId=Integer.parseInt((String) facesContext.getExternalContext().getRequestParameterMap().get("modelId"));
        Integer partId=Integer.parseInt((String) facesContext.getExternalContext().getRequestParameterMap().get("partId"));
    }
    
    private void refreshAttachedParts(int index) {
        Query query=entityManager.createQuery("SELECT m FROM ModelParts m WHERE m.modelId = :modelId");
        query.setParameter("modelId", index);
        attachedParts=query.getResultList();
        for (ModelParts modelPart: attachedParts) {
            //entityManager.detach(modelPart);
        }
    }
    
    @PostConstruct
    private void postConstructChores() {
        //attachedParts=new ArrayList<>();
        Query query;
        entityManager=authorizationTag.getEntityManager();
        
        FacesContext facesContext=FacesContext.getCurrentInstance();
        String passedIndex=(String) facesContext.getExternalContext().getRequestParameterMap().get("index");
        if (passedIndex!=null && !passedIndex.isEmpty()) {
            int index=Integer.parseInt(passedIndex);
            model=entityManager.find(Models.class, index);
            chosenModelType=model.getModelType().getName();
            //entityManager.detach(chosenModelType);
            isExist=true;
            
            refreshAttachedParts(index);
        } else {
            model=new Models();
            isExist=false;
        }
        
        modelTypesList=new ArrayList<>();
        query=entityManager.createNamedQuery("ModelTypes.findAll");
        List<ModelTypes> modelTypes=query.getResultList();
        for (ModelTypes modelType: modelTypes) {
            modelTypesList.add(modelType.getName());
        }
    }
}

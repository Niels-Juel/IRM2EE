/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.rambler.irm2;

import java.io.Serializable;
import java.util.*;
import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;
import ru.rambler.irm2.entries.*;

/**
 *
 * @author a.shalin
 */
@Named(value = "contactHandler")
@ViewScoped
public class ContactHandler implements Serializable{
    @Inject
    private AuthorizationTag authorizationTag;
    private EntityManager entityManager;
    private List<String> companiesList;
    private String chosenCompany;
    private final Integer index;
    private Contacts contactEntity;
    private boolean isPersisted;

    public String getChosenCompany() {
        return chosenCompany;
    }

    public void setChosenCompany(String chosenCompany) {
        this.chosenCompany = chosenCompany;
    }

    public List<String> getCompaniesList() {
        return companiesList;
    }

    public Contacts getContactEntity() {
        return contactEntity;
    }
    
    /**
     * Creates a new instance of ContactHandler
     */
    public ContactHandler() {
        FacesContext facesContext=FacesContext.getCurrentInstance();
        String passedIndex=(String) facesContext.getExternalContext().getRequestParameterMap().get("index");
        index=Integer.parseInt(passedIndex);
        isPersisted = index != -1;
    }
    
    @Transactional(Transactional.TxType.REQUIRED)
    public void submitChanges() {
        if (!chosenCompany.equals(" ")) {
            Query query=entityManager.createNamedQuery("Companies.findByName");
            query.setParameter("name", chosenCompany);
            List<Companies> foundCompanies=query.getResultList();
            if (!foundCompanies.isEmpty()) {
                Companies companyEntity=foundCompanies.get(0);
                contactEntity.setCompanyId(companyEntity.getId());
            } else contactEntity.setCompanyId(null);
        }
        
        if (isPersisted) {
            entityManager.merge(contactEntity);
        } else {
            entityManager.persist(contactEntity);
            isPersisted=true;
        }
    }
    
    @PostConstruct
    private void postConstructChores() {
        entityManager=authorizationTag.getEntityManager();
        
        Query query=entityManager.createNamedQuery("Companies.findAll");
        List<Companies> companies=query.getResultList();
        
        companiesList=new ArrayList<>();
        companiesList.add(" ");
        
        for (Companies company: companies) {
            companiesList.add(company.getName());
        }
        
        if (isPersisted) {
            contactEntity=entityManager.find(Contacts.class, index);
        } else {
            contactEntity=new Contacts();
        }
        
        if (contactEntity.getCompanies()!=null) {
            chosenCompany=contactEntity.getCompanies().getName();
        } else chosenCompany=" ";
    }
}

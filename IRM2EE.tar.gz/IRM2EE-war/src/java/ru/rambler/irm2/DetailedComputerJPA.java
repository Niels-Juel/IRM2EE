/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ru.rambler.irm2;


import ru.rambler.irm2.entries.Computers;
import java.io.Serializable;
import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.*;
import javax.transaction.Transactional;

/**
 *
 * @author a.shalin
 */
@Named
@ViewScoped
public class DetailedComputerJPA implements Serializable{
    @Inject
    private AuthorizationTag authorizationTag;
    
    private Computers computer;
    private EntityManager entityManager;
    private Integer index;
    private String status;

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public Computers getComputer() {
        return computer;
    }

    public void setComputer(Computers computer) {
        this.computer = computer;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public AuthorizationTag getAuthorizationTag() {
        return authorizationTag;
    }

    @Transactional(Transactional.TxType.REQUIRED)
    public void approveChanges() {
        entityManager.merge(computer);
        entityManager.detach(computer);
        entityManager.flush();
    }
    
    /**
     * Creates a new instance of DetailedComputerJPA
     */
    public DetailedComputerJPA() {
        FacesContext facesContext=FacesContext.getCurrentInstance();
        String passedIndex=(String) facesContext.getExternalContext().getRequestParameterMap().get("index");
        index=Integer.parseInt(passedIndex);
    }
    
    @PostConstruct
    private void postConstructChores() {
        entityManager=authorizationTag.getEntityManager();
        computer=entityManager.find(Computers.class, index);
        
        status=computer.getStatus().getName();
        System.out.println(status);
    }
}

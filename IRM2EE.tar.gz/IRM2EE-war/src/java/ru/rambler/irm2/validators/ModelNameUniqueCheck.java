/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.rambler.irm2.validators;

import ru.rambler.irm2.AuthorizationTag;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

/**
 *
 * @author a.shalin
 */
@FacesValidator(value = "modelNameUniqueCheck")
public class ModelNameUniqueCheck implements Validator{
    @Inject
    private AuthorizationTag authorizationTag;
    
    private EntityManager entityManager;
    
    @Override
    public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
        entityManager=authorizationTag.getEntityManager();
        Query query=entityManager.createNamedQuery("Models.findByName");
        query.setParameter("name", (String) value);
        if (!query.getResultList().isEmpty()) {
            throw new ValidatorException(new FacesMessage("Model name is not unique!"));
        }
    }
}

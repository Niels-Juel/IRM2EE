/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ru.rambler.irm2;

import ru.rambler.irm2.entries.Boxes;
import ru.rambler.irm2.entries.Racks;
import ru.rambler.irm2.entries.Store;
import ru.rambler.irm2.entries.Parts;
import ru.rambler.irm2.entries.Locations;
import ru.rambler.irm2.entries.PartTypes;
import ru.rambler.irm2.entries.Manufacturers;
import java.io.Serializable;
import java.util.*;
import javax.annotation.PostConstruct;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.persistence.*;

/**
 *
 * @author a.shalin
 */
@Named(value = "partItemSearch")
@ViewScoped
public class PartItemSearch implements Serializable {
    @Inject
    private AuthorizationTag authorizationTag;
    
    private EntityManager entityManager;
    
    private List<Locations> locations;
    private List<PartTypes> partTypes;
    private final List<Manufacturers> manufacturers;
    private List<Parts> parts;
    private List<Racks> racks;
    private List<Boxes> boxes;
    private List<Store> storeItems;
    private List<String> chosenLocations, chosenRacks, chosenTypes, chosenManufacturers, chosenParts, chosenBoxes, partNames;
    private String serialParts;

    public List<Locations> getLocations() {
        return locations;
    }

    public List<PartTypes> getPartTypes() {
        return partTypes;
    }

    public List<Manufacturers> getManufacturers() {
        return manufacturers;
    }

    public List<Parts> getParts() {
        return parts;
    }

    public List<Racks> getRacks() {
        return racks;
    }

    public List<Boxes> getBoxes() {
        return boxes;
    }

    public List<Store> getStoreItems() {
        return storeItems;
    }

    public List<String> getChosenLocations() {
        return chosenLocations;
    }

    public void setChosenLocations(List<String> chosenLocations) {
        this.chosenLocations = chosenLocations;
    }

    public List<String> getChosenTypes() {
        return chosenTypes;
    }

    public void setChosenTypes(List<String> chosenTypes) {
        this.chosenTypes = chosenTypes;
    }

    public List<String> getChosenManufacturers() {
        return chosenManufacturers;
    }

    public void setChosenManufacturers(List<String> chosenManufacturers) {
        this.chosenManufacturers = chosenManufacturers;
    }

    public List<String> getChosenParts() {
        return chosenParts;
    }

    public void setChosenParts(List<String> chosenParts) {
        this.chosenParts = chosenParts;
    }

    public String getSerialParts() {
        return serialParts;
    }

    public void setSerialParts(String serialParts) {
        this.serialParts = serialParts;
    }

    public List<String> getChosenRacks() {
        return chosenRacks;
    }

    public void setChosenRacks(List<String> chosenRacks) {
        this.chosenRacks = chosenRacks;
    }

    public List<String> getChosenBoxes() {
        return chosenBoxes;
    }

    public void setChosenBoxes(List<String> chosenBoxes) {
        this.chosenBoxes = chosenBoxes;
    }

    public List<String> getPartNames() {
        return partNames;
    }

    public void filterManufacturers() {
        Set<Manufacturers> setManuf=new HashSet<>();
        Query query = entityManager.createNamedQuery("Parts.findByTypes").setParameter("types", chosenTypes);
        List<Parts> listParts = query.getResultList();
        for (Parts partItem: listParts) {
            setManuf.add(partItem.getManufacturer());
        }
        manufacturers.clear();
        for (Manufacturers manufacturer: setManuf) {
            manufacturers.add(manufacturer);
        }
        Collections.sort(manufacturers);
    }
    
    public void filterParts() {
        partNames.clear();
        if (!chosenTypes.isEmpty() && !chosenManufacturers.isEmpty()) {
            Set<String> partNamesSet=new HashSet<>();
            
            String searchQuery="SELECT p FROM Parts p WHERE p.partType.name IN :types AND p.manufacturer.name IN :manufs";
            Query query=entityManager.createQuery(searchQuery);
            query.setParameter("types", chosenTypes);
            query.setParameter("manufs", chosenManufacturers);
            parts=query.getResultList();
//            Collections.sort(parts);
            
            for (Parts partItem: parts) {
                partNamesSet.add(partItem.getName());
            }
            
            partNames.addAll(partNamesSet);
            Collections.sort(partNames);
        }
    }    

    public void filterRacks() {
        Query query = entityManager.createNamedQuery("Racks.findByLocations").setParameter("locNames", chosenLocations);
        racks = query.getResultList();
        Collections.sort(racks);
    }    
    
    public void filterBoxes() {
//        boxes.clear();
        
//        if (!chosenRacks.isEmpty()) {
            Query query=entityManager.createNamedQuery("Boxes.findByRackNames").setParameter("rackNames", chosenRacks);
            boxes=query.getResultList();
            Collections.sort(boxes);
//        }
    }

    public void clearControls() {
        manufacturers.clear();
        racks.clear();
        parts=null;
        boxes=null;
        chosenLocations.clear();
        chosenRacks.clear();
        chosenBoxes.clear();
        chosenTypes.clear();
        chosenTypes.add("HDD");
        chosenParts.clear();
        chosenManufacturers.clear();
        serialParts="";
        storeItems=null;
        
        filterManufacturers();
    }

    public void submitSearch() {
        String searchQueryStr="SELECT st FROM Store st WHERE st.box IS NOT NULL";
        
        if (!chosenLocations.isEmpty()) {
            searchQueryStr+=" AND st.box.rack.location.name IN :locations";
        }
        
        if (!chosenRacks.isEmpty()) {
            searchQueryStr+=" AND st.box.rack.name IN :racks";
        }
        
        if (!chosenBoxes.isEmpty()) {
            searchQueryStr+=" AND st.box.name IN :boxnames";
        }
        
        if (!chosenParts.isEmpty()) {
            searchQueryStr+=" AND st.part.name IN :partnames";
        }
        
        if (!serialParts.equals("")) {
            searchQueryStr+=" AND st.serial IN :serials";
        }
        
        Query searchQuery=entityManager.createQuery(searchQueryStr+" ORDER BY st.box.name");
        if (!chosenLocations.isEmpty()) {
            searchQuery.setParameter("locations", chosenLocations);
        }
        
        if (!chosenRacks.isEmpty()) {
            searchQuery.setParameter("racks", chosenRacks);
        }
        
        if (!chosenBoxes.isEmpty()) {
            searchQuery.setParameter("boxnames", chosenBoxes);
        }
        if (!chosenParts.isEmpty()) {
            searchQuery.setParameter("partnames", chosenParts);
        }
        if (!serialParts.equals("")) {
            searchQuery.setParameter("serials", CentralPoint.parse(serialParts));
        }
        
        storeItems=searchQuery.getResultList();
    }
        
    public PartItemSearch() {
        serialParts="";
        
        manufacturers=new ArrayList<>();
        racks=new ArrayList<>();
        boxes=new ArrayList<>();
        
        chosenLocations=new ArrayList<>();
        chosenRacks=new ArrayList<>();
        chosenTypes=new ArrayList<>();
        chosenParts=new ArrayList<>();
        chosenManufacturers=new ArrayList<>();
        partNames=new ArrayList<>();
        
        chosenTypes.add("HDD");
    }
    
    @PostConstruct
    private void postConstructChores() {
        entityManager=authorizationTag.getEntityManager();
        
        locations=authorizationTag.getLocations();
        partTypes=authorizationTag.getPartTypes();
        filterManufacturers();
    }
}
